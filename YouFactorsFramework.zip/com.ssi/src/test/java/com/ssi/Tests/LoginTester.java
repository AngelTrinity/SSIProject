package com.ssi.Tests;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.asserts.Assertion;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import BaseClass.*;
import Utilities.*;
import com.ssi.Pages.*;


public class LoginTester extends TestBaseClass 
{

	static LoginPageClass loginpage;
	static HomePageClass homepage;
	static NavigateToClass navpage;
	static FindElementsinNM findpage;
	static ExtentTest logintest,hometest,navtest,NMtest;
	static boolean flag1;
	int count1;
	// Constructor
	public LoginTester() throws IOException, FileNotFoundException 
	{
		super();
	}

	@BeforeMethod
	public static void Initialiser() throws FileNotFoundException,IOException
	{
		TestBaseClass.initialize();
		loginpage = new LoginPageClass(driver);
		homepage = new HomePageClass(driver);
		navpage = new NavigateToClass(driver);
		findpage = new FindElementsinNM(driver);
		logintest = extent.createTest("Login Page Test");
		hometest = extent.createTest("Landing page Test");
		navtest = extent.createTest("Navigation Test");
		NMtest= extent.createTest("NearMiss Test");
	}


	//instantiate
	@Test(priority = 1)
	public  static void lookup()
	{

		String URL = prop.getProperty("url");

		logintest.log(Status.INFO,URL);
		logintest.log(Status.INFO, "logging in");
		loginpage.toLogin(prop.getProperty("username"),prop.getProperty("password"));
		logintest.log(Status.INFO,"logged in");
		String title = loginpage.verifyTitle();
		Assert.assertEquals(title, "YouFactors");
		logintest.log(Status.PASS,"title verified");

		boolean logo = loginpage.validateLogo();
		Assert.assertEquals(logo,true);
		logintest.log(Status.PASS,"entered login page and asserted successfully!");

	}
	@Test(priority=2)
	//Navigating to landing page and ASSERTION 
	public static void home()
	{

		String landingpgheader = homepage.verifyHeader();
		Assert.assertEquals(landingpgheader, "Courses");
		hometest.log(Status.PASS,"Navigated to homepage and header verified");

	}	
	@Test(priority=3)
	//moving to near miss 
	public static void  nearmiss()
	{
		String nmheader = navpage.clickNm();
		Assert.assertEquals(nmheader, "Add Near Miss");
		navtest.log(Status.PASS,"Navigated to Near Miss page and header verified");

	}
	@Test(priority=4)
	public static void labelverify()
	{
		NMtest.log(Status.INFO,"Entered Near Miss Page");
		HashMap<Integer,String> map1=new HashMap<Integer,String>();
		NMtest.log(Status.INFO,"Accessing all Qs in the NM page");
		map1 = findpage.findQsInNM();
		for(int i=0;i<7;i++){
			NMtest.log(Status.INFO,map1.get(i));
		}
		if(!map1.isEmpty())
		{
			NMtest.log(Status.PASS,"All the Questions are displayed ");
		}
		else
		{
			NMtest.log(Status.FAIL,"Looks like Question labels are not visible in the page");
		}
		//flag1 = findpage.VerifyImgVisibility();
	}


	@Test(priority=5)
	public static void clickableImagesVerify()
	{
		int imagecount =  findpage.findclickableImagesInNM();
		//NMtest.log(Status.INFO,imagecount);
		NMtest.log(Status.INFO," Clickable images are being located in NM Page");
		if (imagecount == 12 )
		{
			NMtest.log(Status.PASS,"Clickable images are found and are visible");
		}

		else if (imagecount == 0)
		{
			NMtest.log(Status.FAIL,"Clickable images are not found and are invisible");
		}
	}
	//boolean  flag1 = findpage.VerifyImgVisibility();
	@Test(priority=6)
	public static void nonClickableImageVerify()
	{	

		 	boolean  flag1 = findpage.VerifyImgVisibility();
		NMtest.log(Status.INFO,"NonClickable Image verification");

		try {
			Assert.assertTrue(flag1);
		} catch (Throwable t ) {
			NMtest.log(Status.FAIL,"NonClickable Image on the RHS of the NM Page is not visible");
			t.printStackTrace();
		}
		NMtest.log(Status.PASS,"NonClickable Image on the RHS of the NM Page is visible");
	}

	@AfterSuite
	public void teardown()
	{
		driver.quit();
		extent.flush();
	}

}

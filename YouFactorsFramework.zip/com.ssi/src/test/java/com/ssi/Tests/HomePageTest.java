package com.ssi.Tests;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.ssi.Pages.*;

import BaseClass.TestBaseClass;

public class HomePageTest extends TestBaseClass {
static HomePageClass  homepage;
static ExtentTest   hometest;
public HomePageTest() throws IOException, FileNotFoundException {
		super();
 }


	@BeforeTest
	public static void prep()
	{
		homepage = new HomePageClass(driver);
		 hometest = extent.createTest("Landing page Test");
	}
	@Test
	public void hp()
	{

		String landingpgheader = homepage.verifyHeader();
		Assert.assertEquals(landingpgheader, "Courses");
		hometest.log(Status.PASS,"Navigated to homepage and header verified");
		
		
	}

}

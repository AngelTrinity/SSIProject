package com.ssi.Tests;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.ssi.Pages.NavigateToClass;
import com.ssi.Pages.LoginPageClass;
import BaseClass.TestBaseClass;

public class NavigateToTest extends TestBaseClass {
    static LoginPageClass loginpage;
	static NavigateToClass navigatepage;
	static ExtentTest navigatetest;

	   public NavigateToTest() throws IOException, FileNotFoundException {
			super();
	   }
	@BeforeTest
	public static void Initialiser() throws FileNotFoundException,IOException
	{
		TestBaseClass.initialize();
		loginpage = new LoginPageClass(driver);
	    navigatepage = new NavigateToClass(driver);
	   navigatetest = extent.createTest("Navigation ");
		}
	@Test
	public static void navigation()
	{   loginpage.toLogin("Happy","test1234");
		navigatepage.clickMenuIcon();
		navigatepage.clickMenuIcon();
		String header = navigatepage.clickNm();
		navigatetest.log(Status.INFO,"Entering Near Miss Page");
		Assert.assertEquals(header,"Add Near Miss");
		navigatetest.log(Status.PASS,"Landed in Near Miss Page");
		System.out.println("header in this page is"+header);
		System.out.println("checked navigation");
	}
	@AfterTest
	public void create()
	{
		
	extent.flush();	
	}
	
}

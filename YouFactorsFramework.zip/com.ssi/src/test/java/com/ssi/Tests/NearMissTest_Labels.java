package com.ssi.Tests;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.ssi.Pages.FindElementsinNM;
import com.ssi.Pages.LoginPageClass;
import com.ssi.Pages.NavigateToClass;
import com.ssi.Pages.AlertCaptureCheck;

import BaseClass.TestBaseClass;

public class NearMissTest_Labels extends TestBaseClass {
	static LoginPageClass loginpage;
	static NavigateToClass navigatepage;
	static  FindElementsinNM findImages;
	static AlertCaptureCheck findtoastMsg;
	static ExtentTest NMLabeltest,NMImagestest,NMClickImagestest,NMAllLabelstest,ToastMsgtest;
	static HashMap<Integer, String> imageList,labelList;

	//constructor
	public NearMissTest_Labels() throws IOException, FileNotFoundException {
		super();
	}
	@BeforeTest
	public static void Initialiser() throws FileNotFoundException,IOException
	{
		TestBaseClass.initialize();
		loginpage = new LoginPageClass(driver);
		navigatepage = new NavigateToClass(driver);
	/*	NMLabeltest = extent.createTest("Navigation");
		NMImagestest = extent.createTest("Near Miss Non-clickable Image Verification");
		NMClickImagestest=extent.createTest("Clickable Images verification");
		NMAllLabelstest = extent.createTest("Labels identification and verification");
		*/
		loginpage.toLogin("Happy","test1234");
		//navigatepage.clickMenuIcon();
		//navigatepage.clickMenuIcon();
		navigatepage.clickNm();
		navigatepage.clickMenuIcon();
		// FindElementsinNM findImages = new FindElementsinNM(driver);
	}
	@Test
	public void verifyimages()
	{
		FindElementsinNM findImages = new FindElementsinNM(driver);
		imageList = findImages.findclickableImagesInNM();
		//NMtest.log(Status.INFO,imagecount);
		NMLabeltest.log(Status.INFO,"Navigated to Near miss page");
		//NMClickImagestest.log(Status.INFO," Clickable images are being located in NM Page");
		int imagecount=	findImages.findclickableImagesCount();
		//for(int i=0;i<imagecount;i++)
		/*{
			if (imageList.isEmpty())
			{
				//NMClickImages
				//test.log(Status.FAIL,"Clickable images are not found and are invisible");
			}
			else					  
			{
				NMClickImagestest.log(Status.PASS,"Clickable images are found and are visible");
			}
		*/	
	//	clickable images count 
			NMClickImagestest.log(Status.INFO, "clickable images count is:");
			String info = Integer.toString(imagecount);
			NMClickImagestest.log(Status.INFO, info);

		//non-clickable image visibility check
		boolean flag =findImages.VerifyImgVisibility();
		try {
			Assert.assertTrue(flag);
			//NMImagestest.log(Status.PASS,"NonClickable Image is visible");
		} catch (Throwable t) {
		   // NMImagestest.log(Status.FAIL,"NonClickable Imagein NM page not visible");
			t.printStackTrace();
		}
		//identifying all labels in NM page 
		labelList = findImages.findLabelsInNM();
		 NMAllLabelstest.log(Status.INFO,"Locating labels in Near Miss Page. ");
		// NMAllLabelstest.log(Status.SKIP,"Warning something is missing while looking for labels.");
	     if (labelList.isEmpty())
	     {
	    	 NMAllLabelstest.log(Status.FAIL,"Labels are all identifed but not visible.");
	     }
	     else
	     {
	    	 NMAllLabelstest.log(Status.FAIL,"Labels are all identifed and are visible.");
	     }
	     
	}
/*	@Test
	public void verifyWebElements()
	{
		//verify individual elements on the NM page
	//	FindElementsinNM findingElements = new FindElementsinNM(driver);
		
	}
	*/
	@Test
	public void verifyCorrActionsCheckboxes()
	{
	
		findtoastMsg  = new AlertCaptureCheck(driver);
	String result =	findtoastMsg.CorrectiveOptionsCheckboxes();
	ToastMsgtest.log(Status.INFO,"Checking for Toast message on click of WORK ON HABITS");
	if (result.equals("pass"))
			{
		ToastMsgtest.log(Status.PASS,"Checked for Toast message on click of WORK ON HABITS - Success");
			}
	else {
		ToastMsgtest.log(Status.FAIL,"Toast message did NOT appear on click of WORK ON HABITS");
			}
	ToastMsgtest.log(Status.INFO,"Checking checkbox 14 to verify for next textbox appearance");
	findtoastMsg.CorrectiveOptionsSpecialCheckboxes();
	ToastMsgtest.log(Status.PASS,"Checked all Special checkmarks in Corrective Actions");
	}
	
		@AfterTest
		public void closer()
		{
			extent.flush();
		}

	}

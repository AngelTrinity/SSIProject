package FreshNearMissTests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ssi.Pages.HomePageClass;
import com.ssi.Pages.SettingsClass;

import BaseClass.CustomListenerforTestNG;
import BaseClass.TestBaseClass;
import Utilities.TestUtilities;
@Listeners(CustomListenerforTestNG.class)
public class SettingsClassTest extends TestBaseClass{
	HomePageClass homePage;
	SettingsClass settingsPage;
	//constructor
	public SettingsClassTest()
	{
		super();
	}
	
@Test(groups={"functions"})
	public void SettingPageVerify() throws InterruptedException 
	{
	String username = prop.getProperty("username");
	String password = prop.getProperty("password");
	homePage =	loginPage.toLogin(username,password);
	Thread.sleep(3000);
	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	System.out.println("we are in :"+driver.getCurrentUrl());
	settingsPage=homePage.clickSettings();
	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	System.out.println("we are in :"+driver.getCurrentUrl());
	SettingsClass settingsPage = PageFactory.initElements(driver,SettingsClass.class);

	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	//WebDriverWait wait = new WebDriverWait(driver, 7);
	//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='main-content']/div[1]/div/div[2]/form/div/div[2]/div[2]/div/button")));
	//initialiseSettings();
	settingsPage.verifyheader();
    settingsPage.verifyLogo();
    settingsPage.verifyLabels();
    settingsPage.verifyTitle();
    System.out.println("Settings page  Header,Logo,Labels and Title are verified ");
	}

	
}

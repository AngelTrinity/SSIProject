package FreshNearMissTests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
//import com.ssi.Pages.*;
import com.ssi.Pages.AddNearMissClass;
import com.ssi.Pages.HomePageClass;
import com.ssi.Pages.LoginPageClass;
import com.ssi.Pages.NearMissClass;
import com.ssi.Pages.NearMissListClass;

import BaseClass.TestBaseClass;
import Utilities.TestUtilities;

public class NearMissListClassTest extends TestBaseClass{
	public WebDriver driver;
	//LoginPageClass loginPage;
	NearMissClass nearmissPage,nmPage;	
	//NearMissListClass nearmissListpage;
	HomePageClass homePage;
    public NearMissListClass nmListPage,nearmissListPage;

	//constructor
	public NearMissListClassTest()
	{
		super();
	}
	
public NearMissClass initiationForNMList() throws InterruptedException
{
	    homePage = loginPage.toLogin("Happy", "test1234");
		homePage.clickMenuIcon();
		nmPage =homePage.moveToNearMiss();
		NearMissClass nmPage = PageFactory.initElements(driver,NearMissClass.class);

		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		//nmPage.verifyNMListPresence();
	   // nearmissPage = nmPage;
	   // System.out.println("nmlist is present:"+nmPage.verifyNMListPresence());
		//nearmissListPage = nearmissPage.navigateToNearMissList();
		//NearMissListClass nearmissListPage = PageFactory.initElements(driver,NearMissListClass.class);
        return nmPage;
}
@Test
public void NearMissListverify() throws InterruptedException
{
	nearmissPage=initiationForNMList();
	nearmissPage.navigateToNearMissList();
	/*Assert.assertTrue(nmListPage.labelCheck1());
	Assert.assertTrue(nmListPage.labelCheck2());
	Assert.assertTrue(nmListPage.labelCheck3());
	Assert.assertTrue(nmListPage.labelCheck4());
	Assert.assertTrue(nmListPage.labelCheck5());
	Assert.assertTrue(nmListPage.labelCheck6());
	Assert.assertTrue(nmListPage.labelCheck7());
	Assert.assertTrue(nmListPage.labelCheck8());
	System.out.println("All labels of Near Miss List page are visible and verified");*/
}

}

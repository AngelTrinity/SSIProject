package FreshNearMissTests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.FindFailed;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ssi.Pages.AddNearMissClass;
import com.ssi.Pages.HomePageClass;
import com.ssi.Pages.NearMissClass;
import com.ssi.Pages.SettingsClass;

import BaseClass.CustomListenerforTestNG;
import BaseClass.TestBaseClass;
import Utilities.TestUtilities;
/**
 * @author vimci
 *
 */

@Test(groups = "RunAll")
public class NearMissClassTest extends TestBaseClass
{
	public	NearMissClass nearmissPage,nmPage;	
	HomePageClass homePage;
	AddNearMissClass addnearmissPage;

	/*constructor
	public NearMissClassTest()
	{
		super();
	}*/

	public NearMissClass initiation() throws InterruptedException
	{String username = prop.getProperty("username");
	String password = prop.getProperty("password");
		homePage =	loginPage.toLogin(username, password);
		homePage.clickMenuIcon();
		nmPage =homePage.moveToNearMiss();
		NearMissClass nmPage = PageFactory.initElements(driver,NearMissClass.class);

		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		return nmPage;
	}

	@Test 
	public void moveToNearMiss() throws InterruptedException 
	{
	
		nearmissPage=initiation();
		System.out.println("we are in :"+driver.getCurrentUrl());
		Assert.assertEquals(driver.getCurrentUrl(),"https://qasteercom.devssidevtech.com/schome/nearmiss");
		System.out.println("URL assertion passed"); 
		System.out.println("asserting radio btn");
	}
	@Test 
	public void verifyOpenButton()  throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.verifyOpenButton();
	}
	@Test 
	public void summaryInputCheck() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.enterInSummary();
	}
	@Test (priority = 12)
	public void labelCountInNMPage()throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.labelCount();
	}
	@Test (priority = 13)
	public void verifyLabelsInNM() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.verifyLabelsInNM();
	}
	@Test (priority = 14)
	public void verifyCloseButton()throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.verifyCloseButton();
	}
	@Test (priority = 15)
	public void verifyQlabels() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.CheckQElementVisibilty();
		System.out.println("verified open,close buttons,checked question label visibilty");
	}

	@Test(priority = 16)
	public void VerifyImages() throws InterruptedException
	{
		nearmissPage=initiation();
		nearmissPage.imagesClickAndCount();  
	}

	@Test(priority = 17)
	public void mandatoryCheck() throws InterruptedException
	{

		nearmissPage=initiation();

		nearmissPage.mandatoryfieldsCheck(); 
	}

	@Test(priority = 18)
	public void corrActionsLabelsCheck() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.CAoptionsCheck();
	}
	@Test(priority = 19)
	public void AlertMsgCaptureCheck() throws InterruptedException
	{
		nearmissPage=initiation();
		nearmissPage.alertCaptureCheck();

	}
	@Test(priority = 30)
	public void nearMissListCheck() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.verifyNMListPresence();
	}
	@Test(priority = 32)
	public void moveToNMListPage() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.navigateToNearMissList();
	}
	@Test(priority = 20)
	public void CheckInTypeDropdown() throws InterruptedException
	{

		nearmissPage=initiation();
		ArrayList<String>currList =	nearmissPage.finddropDownList();
		ArrayList<String> expectedList = new ArrayList<String>(Arrays.asList("Safety","Environmental","Ergonomics","Quality","Production","Supply Chain","Finance","Others"));
		Assert.assertEquals(currList, expectedList,"list does not match");
		System.out.println("IncType List is visible and assert passed");
		System.out.println("Current list"+currList);
		System.out.println("Expected List"+expectedList);
	}
	@Test
	public void CheckCorrActionsClick() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.CorrOptionsClick();
	}
	@Test(priority = 22)
	public void CheckIncAtImages() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.imagesIncidentAtCount();
	}
	@Test
	public void ClickIncAtImageAtRandom() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.imagesIncidentAtClick();
	}

	@Test(priority = 24)
	public void ClickSeverity() throws InterruptedException
	{

		nearmissPage=initiation();
		nearmissPage.clickSeverityList();
	}

	@Test(priority = 25)
	public void  verifyStatesAndErrorsLabels() throws InterruptedException
	{
		nearmissPage=initiation();
		nearmissPage.checkStatesLabel();
	}
	@Test
	public void verifySpecialCheckboxes() throws InterruptedException, FindFailed
	{
		nearmissPage=initiation();
		nearmissPage.CorrOptionsClick();
	
	}
	@Test(priority = 8)
	public void verifyChooseImageButton() throws InterruptedException, FindFailed
	{
		nearmissPage=initiation();
		nearmissPage.ChooseImageCheck();
			}
	
	@Test
	public void verifySubmitFunctionality() throws InterruptedException, FindFailed
	{
		nearmissPage=initiation();
		nearmissPage.finddropDownListandclick();
		nearmissPage.validateNMEntry();
	//	nearmissPage.clickSubmit();
			}
	@Test
	public void verifyIncType() throws InterruptedException, FindFailed
	{
		nearmissPage=initiation();
		nearmissPage.finddropDownListandclick();
		
			}
}

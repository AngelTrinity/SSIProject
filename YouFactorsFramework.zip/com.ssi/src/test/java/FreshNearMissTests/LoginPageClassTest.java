package FreshNearMissTests;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ssi.Pages.HomePageClass;

import BaseClass.TestBaseClass;
import Utilities.TestUtilities;

public class LoginPageClassTest extends TestBaseClass {
HomePageClass homePage;	

	
//constructor
public LoginPageClassTest()
{
	super();
}

@Test(priority = 1)
public void MoveToTest() throws InterruptedException {
	System.out.println("We are in : "+driver.getCurrentUrl());
	String username = prop.getProperty("username");
	String password = prop.getProperty("password");
	homePage =	loginPage.toLogin(username,password);
	
//homePage = loginPage.moveToNextPage();
Thread.sleep(3000);
driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
// String expectedURL="https://opensource-demo.orangehrmlive.com/index.php/dashboard";
 //String actualURL=
	System.out.println("We have moved to: "+driver.getCurrentUrl());
//System.out.println("After login ,header is "+homePage.);
	//System.out.println("Course name in landing page :"+ homePage.getCourseName());
}
@Test(priority = 2)
public void logoTest()
{
Assert.assertTrue(loginPage.validateLogo());
System.out.println("logo verified");
}
@Test(priority = 3)
public void TitleTest()
{
//Assert.assertTrue(loginPage.getUrl());
System.out.println("title from Landingpage:"+driver.getTitle());
Assert.assertEquals(driver.getTitle(), "YouFactors");
}
}





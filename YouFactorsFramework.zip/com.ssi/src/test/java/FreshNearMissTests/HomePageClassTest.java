
package FreshNearMissTests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ssi.Pages.HomePageClass;
import com.ssi.Pages.NearMissClass;

import BaseClass.CustomListenerforTestNG;
import BaseClass.TestBaseClass;
import Utilities.TestUtilities;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ssi.Pages.HomePageClass;

import BaseClass.TestBaseClass;
import Utilities.TestUtilities;
//@Listeners(CustomListenerforTestNG.class)
public class HomePageClassTest extends TestBaseClass {
	HomePageClass homePage;	

	//constructor
	public  HomePageClassTest()
	{
		super();
	}


	
	public void MoveToHomePage() throws InterruptedException {
		System.out.println("We are in : "+driver.getCurrentUrl());
		String username = prop.getProperty("username");
		String password = prop.getProperty("password");
		homePage =	loginPage.toLogin(username,password);
	}
	@Test(priority = 8)
	public void verifyHeader()throws InterruptedException
	{   MoveToHomePage();
		Assert.assertTrue(homePage.verifyHeader());
		Thread.sleep(2000);
		System.out.println("We have moved to after few secs: "+driver.getCurrentUrl());
		Assert.assertEquals(driver.getCurrentUrl(),"https://qasteercom.devssidevtech.com/schome/products");
		System.out.println("verified header and URL  in Homepage");
	}
	@Test
	public void verifyHomePageUrl()throws InterruptedException
	{   MoveToHomePage();
		Thread.sleep(2000);
		System.out.println("We have moved to after few secs: "+driver.getCurrentUrl());
		Assert.assertEquals(driver.getCurrentUrl(),"https://qasteercom.devssidevtech.com/schome/products","url verification failed");
		System.out.println("verified URL  in Homepage");
	}
	@Test(priority = 5)
	public void verifyMenuIcon() throws InterruptedException
	{
		MoveToHomePage();
	Assert.assertTrue(homePage.verifyMenuIcon());
	System.out.println("MenuIcon is present");
	}

	@Test(priority = 6)
	public void verifyProfileIcon() throws InterruptedException
	{
		MoveToHomePage();
		Assert.assertTrue(homePage.verifyProfileIcon());
		System.out.println("ProfileIcon is present");
	}

	@Test(priority = 7)
	public void clickMenuIcon() throws InterruptedException
	{
		MoveToHomePage();
		homePage.clickMenuIcon();
		System.out.println("MenuIcon is clicked");
	}
	
}
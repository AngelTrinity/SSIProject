package com.ssi.Pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
/*
 * 
 * Identifies labels and clickable,nonclickable images in NM page
 * 
 * 
 */

public class FindElementsinNM {
	int count1,count2,count3;
	//int count2;
	//locators
	/*
	 * 
	 * @FindBy(how = How.CLASS_NAME, using = "cls_nm_sub_header")
private List<WebElement> elementsNM;
	 */
	//*[@class="cls_subtitle"]
	//@FindBy(how = How.CLASS_NAME, using = "cls_nm_sub_header")
	@FindBy(className = "cls_nm_sub_header")
	private List<WebElement> elementsNM;
	//@FindBy(how = How.CLASS_NAME,using = "checkmark")
	@FindBy(className = "checkmark")
	private List<WebElement> checkmarksNM;
	@FindBy(className = "cls_subtitle")
	private List<WebElement> labelNM;
	@FindBy(xpath = "//*[@class ='cls_sub_grouping2']/img")
	private WebElement nearMissImage;
	@FindBy(xpath = "//*[@class = 'cls_subtitle']")
	private List<WebElement> labelsNM;
	@FindBy (xpath="//*[@id='addNearMiss']/div[1]/div/h3")
    private WebElement NMheader;
	//constructor
	public FindElementsinNM(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
    
	HashMap<Integer,String> map=new HashMap<Integer,String>();
	HashMap<Integer,String> Labelmap=new HashMap<Integer,String>();
	HashMap<Integer,String> imagesCmap=new HashMap<Integer,String>();
	// locating Question labels   
	public HashMap<Integer,String> findQsInNM()
	{

		for ( WebElement e1 : elementsNM ) {

			map.put(count1,e1.getText());
			count1++ ;

		}
		return map;
	}
	//locating Labels in NM page

	public HashMap<Integer,String> findLabelsInNM()
	{

		for ( WebElement e3 : labelNM )
		{

			Labelmap.put(count1,e3.getText());

		}
		return Labelmap;
	}
	//locating all clickable images in Nm page 
	public HashMap<Integer,String> findclickableImagesInNM()
	{
		 int count2=0;
		for ( WebElement e2 : checkmarksNM ) {

			imagesCmap.put(count2, e2.getAttribute("id"));		
					e2.click();
			count2++;
		}
		return imagesCmap;
	}
	public int findclickableImagesCount()
	{
	count3 =0;
		for ( WebElement e3 : checkmarksNM ) {
       if(e3.isSelected())
    	   {
    	   e3.clear();
    	   }
			count3++;
		}
		return count3;
	}
	//Locating non clickable image in  Near Miss page

	public boolean VerifyImgVisibility()
	{
		return nearMissImage.isDisplayed();

	}
	public String getHeader()
	{
		return NMheader.getText();
	}
}


package com.ssi.Pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocator;

import BaseClass.TestBaseClass;
import com.ssi.Pages.*;
import com.ssi.Pages.*;

public class LoginPageClass extends TestBaseClass
{
	
	
	@FindBy(name="username")
	private WebElement username;
	@FindBy(name="password")
	private WebElement password;
	@FindBy(xpath="//*[@class = 'img-fluid safestartlogo']") 
	private WebElement logo;
	@FindBy(xpath="//*[@type ='submit']")
	private WebElement loginBtn;
	@FindBy(xpath="//*[@id='menu-toggle']/img")
	private WebElement menuIcon;
   /* @FindBy(partialLinkText = "Forgot Password")
    private WebElement forgotPassword;
    @FindBy(partialLinkText = "Register with invite code")
    private WebElement registerWithInviteCode;*/
    
	//Constructor
	
		

	public LoginPageClass(WebDriver driver) 
	{
		//this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}
		
			// actions
	public boolean validateLogo()
	
	{

      return  logo.isDisplayed();
			
	}
  //  public String getUrl()
    //{
 //   	return driver.getCurrentUrl();
   // }

	public HomePageClass toLogin(String un,String pwd)
	{
			
		username.sendKeys(un);
		password.sendKeys(pwd);
//	}
	//public HomePageClass moveToNextPage()
//	{
		loginBtn.click();
		return new HomePageClass(driver);
	}

}

package com.ssi.Pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ObjRepo {
	/*
	 * 
	 * locators needed to access until Near miss page
	 * 
	 */
public WebDriver driver;
	
	@FindBy(name="username")
	private WebElement username;
	@FindBy(name="password")
	private WebElement password;
	@FindBy(xpath="//img[@class = 'img-fluid safestartlogo']") 
	private WebElement logo;
	@FindBy(xpath="//*[@type ='submit']")
	private WebElement loginBtn;
	@FindBy(xpath="//*[@id='menu-toggle']/img")
	private WebElement menuIcon;
	
	//landing or homepage
	@FindBy(xpath="//*[@id='main-content']/div[1]/div/div/div/div/div[1]/h3")
	private WebElement LandingpageHeader;
@FindBy(xpath="//*[@id='menu-toggle']/img")
//@FindBy(xpath="//img[@class = 'img-fluid']")
private WebElement MenuIcon;
//@FindBy(xpath="//*[@id='wrappers']/div[1]/div[2]/nav/div/ul[1]/li[2]")
//private WebElement LogoImage;
@FindBy (xpath="//*[@id='navbarDropdown']/img")
private WebElement ProfileIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lblnearmissform']")
private WebElement nearmissIcon;
/*@FindBy(xpath= "//*[@id = 'sidenav']")
private WebElement sidePanel;*/


//navigation 
/*
@FindBy(xpath="//*[@class = 'menubg_sprite lbldashboard']")
private WebElement dashboardIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lblglobalsettings']")
private WebElement settingsIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lblusermanagement']")
private WebElement userMgmtIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lblusers']")
private WebElement usersIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lblgroup']")
private WebElement groupsIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lbltrainingassignment']")
private WebElement trainingAssignmentIcon;
@FindBy(xpath="//*[@id='c5']/a/span")
private WebElement assignmentOption;
@FindBy(xpath="//*[@class = 'menubg_sprite lblsimassignment']")
private WebElement instructorLedTrainingIcon;
@FindBy(xpath="//*[@id='c38']/a/span]")
private WebElement recordCompletionOption;
@FindBy(xpath="//*[@class = 'menubg_sprite lblresources']")
private WebElement resourcesIcon;
@FindBy(xpath="//*[@id='c7']/a/span")
private WebElement steeringCommitteeOption;
@FindBy(xpath="//*[@class = 'menubg_sprite lbltraining']")
private WebElement trainingIcon;
@FindBy(xpath="//*[@id='c9']/a/span")
private WebElement coursesOption;
@FindBy(xpath="//*[@class = 'menubg_sprite lblstoryfeeds']")
private WebElement storyfeedsIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lblrateyourstate']")
private WebElement rateYourStateIcon;
// Near Miss Icon 
/*@FindBy(xpath= "//*[@id = sidenav")
private WebElement sidePanel;
@FindBy(xpath="//*[@class = 'menubg_sprite lblnearmissform']")
private WebElement nearmissIcon;
@FindBy(xpath="//*[@id='menu-toggle']/img")
private WebElement MenuIcon1;

@FindBy(xpath="//*[@class = 'menubg_sprite lblreports']")
private WebElement reportsIcon;
@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Learner Progress')")
WebElement learnerProgressOption;
@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Rate Your State')")
WebElement rateYourStateOption;
@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Learner Course Progress')")
WebElement learnerCourseProgressOption;
@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Near Miss')")
WebElement NearMissOption;
@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Safestart Survey')")
WebElement safestartSurveyOption;
@FindBy(xpath="//*[@class = 'menubg_sprite lbltempletes']")
private WebElement templatesIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite lblriskpattern']")
private WebElement riskPatternIcon;
@FindBy(xpath="//*[@class = 'menubg_sprite rcd q&a']")
private WebElement RCDIcon;
@FindBy(xpath="//img[@class = 'img-fluid']")
private WebElement MenuIcon1;*/

@FindBy(xpath="//h3")
private WebElement header3;


//near miss page

//locators
	/*
	 * 
	 * @FindBy(how = How.CLASS_NAME, using = "cls_nm_sub_header")
private List<WebElement> elementsNM;
	 
	//*[@class="cls_subtitle"]
	//@FindBy(how = How.CLASS_NAME, using = "cls_nm_sub_header")*/
	@FindBy(className = "cls_nm_sub_header")
	private List<WebElement> elementsNM;
	//@FindBy(how = How.CLASS_NAME,using = "checkmark")
	@FindBy(className = "checkmark")
	private List<WebElement> checkmarksNM;
	@FindBy(className = "cls_subtitle")
	private List<WebElement> labelNM;
	@FindBy(xpath = "//*[@class ='cls_sub_grouping2']/img")
	private WebElement nearMissImage;
	@FindBy(xpath = "//*[@class = 'cls_subtitle']")
	private List<WebElement> labelsNM;
	@FindBy (xpath="//*[@id='addNearMiss']/div[1]/div/h3")
  private WebElement NMheader;
	
	
	
	//Constructor
	
	

		public ObjRepo(WebDriver driver2) {
			PageFactory.initElements(driver,this);
	}

		
		/*
		 * 
		 * 
		 * Action methods
		 * 
		 * 
		 * 
		 */
		public boolean validateLogo()
		
		{

	      return  logo.isDisplayed();
				
		}
	public boolean validateMenuIcon()
		
		{

	      return  menuIcon.isDisplayed();
				
		}
		public String verifyTitle()
				{
		
			return driver.getTitle();
		}
	

		public void toLogin(String un,String pwd)
		{
				
			username.sendKeys(un);
			password.sendKeys(pwd);
			loginBtn.sendKeys(Keys.ENTER);
		}
	//Action classes from nav
		//Action methods
		public String verifyHeader()
		{
			return LandingpageHeader.getText();
		}
	/*	public void goTosidePanel()
		{
			sidePanel.click();
		}
		public boolean verifyLogoImage()
		{
		return	LogoImage.isDisplayed();
		}
		*/
		public boolean verifyMenuIcon()
		{
		return	MenuIcon.isDisplayed();
		}
		public boolean verifyProfileIcon()
		{
		return	ProfileIcon.isDisplayed();
		}
		public void clickMenuIcon()
		{
			MenuIcon.click();
		 
		}
		public void  goToNMPage()
		{ 
			nearmissIcon.sendKeys(Keys.ENTER);
		}
		

}


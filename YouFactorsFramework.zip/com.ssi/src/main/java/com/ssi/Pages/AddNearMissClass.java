package com.ssi.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.TestBaseClass;

public class AddNearMissClass extends TestBaseClass{
	public WebDriver driver;
	
	HomePageClass homePage;
//locators 
	@FindBy(xpath = "//*[@id='showlistadd']")
	private WebElement  nearMissListLink;
	//Corr Actions locators
	@FindBy(id = "CActions")
	 private WebElement  corrActionOptions;
    List<WebElement> checkboxes = corrActionOptions.findElements(By.tagName("li"));
   @FindBy(xpath = "//*[@id='Type_input']")
    private WebElement incType;
   @FindBy(xpath = "//*[@id='inc_title']/div/div") 
    private WebElement incTitle;
   @FindBy(xpath = "//*[@id='Date']")
    private WebElement incDate ;
   @FindBy(xpath = "//*[@id='Time']")  
    private WebElement incTime ;
   @FindBy(xpath = "//*[@id='Placeid1']")
    private WebElement incAt;
   @FindBy(xpath = "//*[@id='Location_input']")
    private WebElement location ;
   @FindBy(xpath = "//*[@id='Department_input']")
    private WebElement department;
     @FindBy(xpath = "//*[@id='menuList']")
   private WebElement severity;
     @FindBy(xpath = "//*[@id='addchoose']") 
    private WebElement chooseImg;
      @FindBy(xpath = "//*[@id='States']/div/label/img")
    private WebElement states ;
     @FindBy(xpath = "//*[@id='Errors']/div/label/img")
    private WebElement errors ;
     @FindBy(xpath = "//*[@id('CActions']")
    private WebElement corrActionsOptions;
     @FindBy(xpath= "//*[@class='checkboxmark' and @id= '3']")
     private  WebElement checkboxWOH;
     @FindBy(xpath= "//*[@class='checkboxmark' and @id= '14']")
     private  WebElement checkboxOthers;
     @FindBy(xpath= "//*[@id='Summary']")
     private WebElement summary;
     @FindBy(xpath = "//*[@id='txtCA']")
     private WebElement othersTxtBox;
    // WebElement checkboxWOH = driver.findElement(By.xpath("//*[@class=\"checkboxmark\" and @id= \"3\"]"));
    // WebElement checkboxOthers = driver.findElement(By.xpath("//*[@class=\"checkboxmark\" and @id= \"14\"]"));
  //   List<WebElement> checkboxes = corrActionOptions.findElements(By.tagName("li"));
	
	//constructor
	public AddNearMissClass(WebDriver driver) 
	{
			PageFactory.initElements(driver, this);
	}
	
	//actions
	public void CAoptionsCheck() throws InterruptedException
	{
    ArrayList<Integer> numsLeft = new ArrayList<Integer>(Arrays.asList(0,1,2));
    ArrayList<Integer> numsLeft1 = new ArrayList<Integer>(Arrays.asList(3,4,5,6,7,8,9,10,11,12,13,14,15));
   
   Random random = new Random();
   int result = random.nextInt(numsLeft.size());
   int result1 = random.nextInt(numsLeft1.size());
   System.out.println("random number chosen for first list is"+result);
   System.out.println("random number chosen for second list is"+result1);
   
   Actions CAoptions = new Actions(driver);
   //using Actions to do all operations in one go
    
     	
    
    CAoptions.moveToElement(checkboxes.get(result)).click()
    
    .moveToElement(incTitle).click().sendKeys("hamsavardhini")
    .moveToElement(incType).clickAndHold().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER)
    .moveToElement(incAt).click()
    .moveToElement(location).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER)
    .moveToElement(department).click().sendKeys(Keys.DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER)
    .moveToElement(summary).click().sendKeys("this is test summary ").sendKeys(Keys.ENTER)
     .moveToElement(states).sendKeys(Keys.ENTER).sendKeys(Keys.ENTER)
     .moveToElement(errors).sendKeys(Keys.ENTER).sendKeys(Keys.ENTER)
    
    
    
    
   .moveToElement(checkboxWOH).click().pause(2000)
   .moveToElement(checkboxes.get(result1)).click()
   .moveToElement(checkboxOthers).click()
   .moveToElement(othersTxtBox).click().sendKeys("final testing box")
  // .moveToElement(submit_btn).click()
    .build().perform();
    

    Thread.sleep(5000);
    
    	}
   
   
   
   
   
   
}

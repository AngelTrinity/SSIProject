package com.ssi.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AlertCaptureCheck {
	public WebDriver driver;
	public static String toastMsgresult;
	//static Actions CAoptions;
	// locators
	@FindBy(how = How.CLASS_NAME,using ="checkboxmark")
	private List<WebElement> checkboxes;

	// find the special boxes 
	@FindBy(how = How.XPATH,using ="//*[@class='checkboxmark' and @id= '3']")
	private WebElement checkboxWOH ;
	@FindBys({@FindBy(how = How.CLASS_NAME,using ="checkboxmark"),@FindBy(how = How.ID,using ="14")})
		private WebElement checkboxOthers;

	@FindBy(how = How.ID,using ="txtCA")
	private WebElement othersTxtBox;

	@FindBy(how = How.XPATH,using ="//*[@id=\"addNearMiss\"]/section/div/div[3]/button[2]")
	private WebElement submit_btn ;
	//@FindBy(how = How.CLASS_NAME,using ="MuiAlert-message")
	//private WebElement alertmsg;

	//constructor
	public AlertCaptureCheck(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
		
	}
	//action methods
	public void  CorrectiveOptionsCheckboxes() throws InterruptedException
	{

		// Verifying CAoptions Special checkboxes and their new options and toast messages ");


		checkboxes.get(2).click();

		checkboxWOH.click();
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement alertmsg = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class = 'MuiAlert-message']")));
		if (alertmsg.isDisplayed())
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("Fail") ;
		}
		Thread.sleep(3000);
		checkboxOthers.click();
		othersTxtBox.click();
    	othersTxtBox.sendKeys("Last textbox of the page");
		
		
	}
	
	
	/*
	
	
		
		public void CorrectiveOptionsSpecialCheckboxes()
		{
		 
		

	}*/

	}


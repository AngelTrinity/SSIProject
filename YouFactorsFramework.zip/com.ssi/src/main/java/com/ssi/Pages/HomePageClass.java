package com.ssi.Pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ssi.Pages.NearMissClass;

public class HomePageClass {
	public static  WebDriver driver;
	//locators
	
	//@FindBy(xpath="//*[@id='main-content']/div[1]/div/div/div/div/div[1]/h3")
	@FindBy(xpath="//*[@class = 'section-header']/h3")
	private WebElement LandingpageHeader;
	@FindBy(xpath="//*[@id='menu-toggle']/img")
	//@FindBy(xpath="//*[@class='img-fluid']")
	private WebElement MenuIcon;
	@FindBy (xpath="//*[@id='navbarDropdown']/img")
	private WebElement ProfileIcon;
	//@FindBy(xpath="//*[@class = 'menubg_sprite lblnearmissform']")
	@FindBy(xpath = "//*[@id='sidenav']/div/div/div[10]/div/a/span")
	private WebElement nearmissIcon;
	@FindBy(xpath="//*[@id='addNearMiss']/div[1]/div/h3")
	private WebElement nearMissHeader;
	@FindBy(xpath="//*[@id='sidenav']/div/div/div[1]/div/a/span")
	private WebElement dashboard;
	@FindBy(xpath="//*[@id='sidenav']/div/div/div[2]/div/a")
	private WebElement settings;
 

//	@FindBy(xpath= "//*[@class = 'overlay']")
	//private List<WebElement> courses;
	
	//NearMissClass nearmissPage;

	//constructor
	public HomePageClass(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
	}
	//Action methods
	public void clickDashboard()
	{
		dashboard.click();
	
	}
public SettingsClass clickSettings()
{
	settings.click();
	return new SettingsClass(driver);
}
	/*	public void goTosidePanel()
	{
		sidePanel.click();
	}
	public boolean verifyLogoImage()
	{
	return	LogoImage.isDisplayed();
	}
	 */
	public boolean verifyMenuIcon()
	{
		return	MenuIcon.isDisplayed();
	}
	public boolean verifyProfileIcon()
	{
		return	ProfileIcon.isDisplayed();
	}
	public void clickMenuIcon()
	{
		if(MenuIcon.isDisplayed())
	    {
		MenuIcon.click();
		}
	else 
    	{
		System.out.println("MenuIcon is not visible.Check the error message and rectify the issue");
		}


	}
	public boolean verifyHeader()
	{
		return  LandingpageHeader.isDisplayed();
	}
	/*public String verifyNearMissHeader()
	{
		return nearMissHeader.getText();
	}*/
	public NearMissClass  moveToNearMiss() 
	{
		MenuIcon.click();
		nearmissIcon.click();
		return  new NearMissClass(driver);
	}
}

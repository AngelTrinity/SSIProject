package com.ssi.Pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.TestBaseClass;

public class SettingsClass  extends TestBaseClass{
public	WebDriver driver;
	
//locators
//header 
@FindBy(xpath = "//*[@id='main-content']/div[1]/div/div[1]/h3")
private WebElement header;
//title
@FindBy(xpath ="//*[@id='main-content']/div[1]/div/div[2]/form/div/div[1]/div[1]/h1/b")
private WebElement pageTitle;
//logo
@FindBy(xpath ="//*[@id='main-content']/div[1]/div/div[2]/form/div/div[1]/div[2]/div/div/img")
private WebElement pageLogo;
//edit button
@FindBy(xpath ="//*[@id='main-content']/div[1]/div/div[2]/form/div/div[2]/div[2]/div/button")
private WebElement editButton;
//check for labels
@FindBy(xpath = "//*[@class='form-group row ssi-settings-row']/label")
private List<WebElement> labels;
//constructor 
public SettingsClass(WebDriver driver)
{
	PageFactory.initElements(driver, this);
}
//Action methods 
public void verifyheader()
{
	header.isDisplayed();
}
public void verifyTitle()
{
	pageTitle.isDisplayed();
}
public void verifyLogo()
{
	pageLogo.isDisplayed();
}
public void verifyLabels()
{
	int count = 1;
	for ( WebElement e1 : labels ) 
	{
    System.out.println("label :"+e1.getText());
			count++ ;
	}
	System.out.println("number of labels is :"+ count);
}
}

package com.ssi.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.BaseClassEx;

public class HomePageClassEx extends BaseClassEx{
	WebDriver driver;
	//locators
		@FindBy(xpath="//*[@id='main-content']/div[1]/div/div/div/div/div[1]/h3")
			private WebElement LandingpageHeader;
		@FindBy(xpath="//*[@id='menu-toggle']/img")
		//@FindBy(xpath="//img[@class = 'img-fluid']")
		private WebElement MenuIcon;
		//@FindBy(xpath="//*[@id='wrappers']/div[1]/div[2]/nav/div/ul[1]/li[2]")
		//private WebElement LogoImage;
		@FindBy (xpath="//*[@id='navbarDropdown']/img")
		private WebElement ProfileIcon;
		@FindBy(xpath="//*[@class = 'menubg_sprite lblnearmissform']")
		private WebElement nearmissIcon;
		//@FindBy(xpath= "//*[@id = 'sidenav']")
		//private WebElement sidePanel;
		NavigateToClass navigateToMenu;
		
		//constructor
		public HomePageClassEx(WebDriver driver) 
		{
			this.driver = driver;
			
		}
	//Action methods
		public String verifyHeader()
		{
			return LandingpageHeader.getText();
		}

		public boolean verifyMenuIcon()
		{
		return	MenuIcon.isDisplayed();
		}
		public boolean verifyProfileIcon()
		{
		return	ProfileIcon.isDisplayed();
		}
		public void clickMenuIcon()
		{
			MenuIcon.click();
		   // MenuIcon.click();
			//navigateToMenu = new com.ssi.Pages.NavigateToClass(driver);
		//	return  new NavigateToClass(driver);
			
		}

}

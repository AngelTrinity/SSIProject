package com.ssi.Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.TestBaseClass;
import Utilities.TestUtilities;

public class NearMissListClass extends TestBaseClass {
	public WebDriver driver;
	NearMissClass nearmissPage,nmPage;	
	NearMissListClass nearmissListpage;
	HomePageClass homePage;
    NearMissListClass nmListPage,nearmissListPage;
	//locators 
	/*
	 * locating labels in NM List page
	 * 
	 */
	@FindBy(xpath = "//*[@id='column-incident_id']")
	private WebElement incIdLabel;
	
	@FindBy(xpath = "//*[@id='column-incident_Title']")
	private WebElement incTitleLabel;
	
	@FindBy(xpath = "//*[@id='column-incident_Type']")
	private WebElement incTypeLabel;
	
	@FindBy(xpath = "//*[@id='column-incident_Severity']")
	private WebElement severityLabel;
	
	@FindBy(xpath = "//*[@id='column-Location']")
	private WebElement locationLabel;
	
	@FindBy(xpath = "//*[@id='column-event_Date']")
	private WebElement dateLabel;
	
	@FindBy(xpath = "//*[@id='column-status']")
	private WebElement statusLabel;
	
	@FindBy(xpath = "//*[@id='column-actions']")
	private WebElement actionsLabel;
	//contructor 
	public  NearMissListClass(WebDriver driver)
	{
		
		PageFactory.initElements(driver,this);
	}
	//methods
	/*public NearMissListClass initiationOfNMList() throws InterruptedException
	{
		 homePage =	loginPage.toLogin("Happy", "test1234");
			homePage.clickMenuIcon();
			nmPage =homePage.moveToNearMiss();
			NearMissClass nmPage = PageFactory.initElements(driver,NearMissClass.class);
			nearmissListPage = nmPage.navigateToNearMissList();
			nmListPage=nearmissListPage;

			driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	return nmListPage;
	}*/

	public boolean labelCheck1()
	{
	return incIdLabel.isDisplayed();
		}
	
	public boolean labelCheck2()
	{
	return incTitleLabel.isDisplayed();
		}
	
	public boolean labelCheck3()
	{
	return incTypeLabel.isDisplayed();
		}
	
	public boolean labelCheck4()
	{
	return severityLabel.isDisplayed();
		}
	
	public boolean labelCheck5()
	{
	return locationLabel.isDisplayed();
		}
	
	public boolean labelCheck6()
	{
	return dateLabel.isDisplayed();
		}
	
	public boolean labelCheck7()
	{
	return statusLabel.isDisplayed();
		}
	
	public boolean labelCheck8()
	{
	return actionsLabel.isDisplayed();
		}

}

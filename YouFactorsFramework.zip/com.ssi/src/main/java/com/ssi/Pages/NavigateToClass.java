package com.ssi.Pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NavigateToClass {
	
	public WebDriver driver;

	/*locators
	@FindBy(xpath="//*[@class = 'menubg_sprite lbldashboard']")
	private WebElement dashboardIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblglobalsettings']")
	private WebElement settingsIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblusermanagement']")
	private WebElement userMgmtIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblusers']")
	private WebElement usersIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblgroup']")
	private WebElement groupsIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite lbltrainingassignment']")
	private WebElement trainingAssignmentIcon;
	@FindBy(xpath="//*[@id='c5']/a/span")
	private WebElement assignmentOption;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblsimassignment']")
	private WebElement instructorLedTrainingIcon;
	@FindBy(xpath="//*[@id='c38']/a/span]")
	private WebElement recordCompletionOption;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblresources']")
	private WebElement resourcesIcon;
	@FindBy(xpath="//*[@id='c7']/a/span")
	private WebElement steeringCommitteeOption;
	@FindBy(xpath="//*[@class = 'menubg_sprite lbltraining']")
	private WebElement trainingIcon;
	@FindBy(xpath="//*[@id='c9']/a/span")
	private WebElement coursesOption;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblstoryfeeds']")
	private WebElement storyfeedsIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblrateyourstate']")
	private WebElement rateYourStateIcon;*/
	// Near Miss Icon 
	@FindBy(xpath= "//*[@id = sidenav")
	private WebElement sidePanel;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblnearmissform']")
	private WebElement nearmissIcon;
	@FindBy(xpath="//*[@id='menu-toggle']/img")
	private WebElement MenuIcon1;
	/*@FindBy(xpath="//*[@class = 'menubg_sprite lblreports']")
	private WebElement reportsIcon;
	@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Learner Progress')")
	WebElement learnerProgressOption;
	@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Rate Your State')")
	WebElement rateYourStateOption;
	@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Learner Course Progress')")
	WebElement learnerCourseProgressOption;
	@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Near Miss')")
	WebElement NearMissOption;
	@FindBy(xpath="//*[@id='c18']/a/span and contains(text(), 'Safestart Survey')")
	WebElement safestartSurveyOption;
	@FindBy(xpath="//*[@class = 'menubg_sprite lbltempletes']")
	private WebElement templatesIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite lblriskpattern']")
	private WebElement riskPatternIcon;
	@FindBy(xpath="//*[@class = 'menubg_sprite rcd q&a']")
	private WebElement RCDIcon;
	@FindBy(xpath="//img[@class = 'img-fluid']")
	private WebElement MenuIcon1;
	
	@FindBy(xpath="//h3")
	private WebElement header3;
	 FindElementsinNM NMpage;*/
	/*
	 * to find the submune under user management - users and groups 
	 * //*[@id="c2"]/a
	 * 
	 * 
	 */
	
	//constructor
	public NavigateToClass(WebDriver driver) {
		//this.driver = driver;
		PageFactory.initElements(driver, this);
	}
//Action methods
	public void clickMenuIcon1()
	{
		MenuIcon1.click();
		
	}
	
/*	public void clickDashboard()
	{
		dashboardIcon.click();
	}
	*/
	
	public void goToNMPage()
	{ 
		//sidePanel.click();
		nearmissIcon.click();
		//MenuIcon1.click();
	//NMpage = new com.ssi.Pages.FindElementsinNM(driver);
	//return new FindElementsinNM(driver);
	}
	
}

package com.ssi.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
//import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.openqa.selenium.interactions.Actions;

import BaseClass.TestBaseClass;

public class NearMissClass extends TestBaseClass{



	//locators for labels 
	@FindBy(xpath = "//*[@id='showlistadd']")
	private WebElement  nearMissListLink;
	@FindBy(className = "cls_nm_sub_header")
	private List<WebElement> elementsNM;
	@FindBy(className = "checkmark")
	private List<WebElement> checkmarksNM;

	//corr actions locator


	// @FindBy(xpath = "//*[@class='custom-control-checkbox']")
	@FindBy(xpath = "//*[@class='near_chk_left']/div")
	private List<WebElement> checkboxForCorrActions;

	//inc type dropdown locator
	@FindBy(xpath = "//*[@id='Type']/div[1]/i")
	private WebElement IncTypeDownIcon;
	@FindBy(className = "optionContainer")
	private WebElement listOfIncTypes;

	//locating incident at images 
	@FindBy(xpath = "//*[@class='col-md-2 col-sm-12 column_plc']")
	private List<WebElement> imagesIncAt;

	//locating states list
	//@FindBy(xpath ="//label[@class='check-lbl check-lbl-states']")
	//@FindBys({
	@FindBy(className = "cls-img-states")
	//@FindBy(className = "rys-text")})
	private List<WebElement> statesList;
	@FindBy(xpath = "//*[@class='column']/div/span")
	private List<WebElement>statesAndErrorsLabel;

	//	@FindBy(className ="cls_subtitle")
	//  private List<WebElement> labelNM;  
	//	@FindBy (xpath="//*[@id='addNearMiss']/div[1]/div/h3")
	//	private WebElement nearMissHeader;
	//open,close and summary
	@FindBy (xpath = "//input[@id='radio1']")	
	private WebElement openRadioBtn;
	@FindBy (xpath = "//input[@id='radio2']")	
	private WebElement closeRadioBtn;
	@FindBy (xpath = "//*[@id='Summary']")	
	private WebElement summary_input;

	// locating choose image button
	@FindBy (xpath = "//*[@id='addchoose']")	
	private WebElement chooseImage ;
	//= driver.findElement(By.id("addchoose"));

	//labels and cancel submit buttons

	@FindBy(xpath = "//label[@class = 'cls_subtitle']")
	private List<WebElement> labelsNM;
	@FindBy(xpath = "//*[@id='addNearMiss']/section/div/div[3]/button[2]")
	//@FindBy(xpath="//*[@type='submit']")
	private WebElement submitBtn;
	@FindBy(xpath = "//*[@id=\"addNearMiss\"]/section/div/div[3]/button[1]")
	private WebElement cancelBtn;
	/*
	 * 	 * find checkboxes elements
	 */ 

	//
	/*find the special boxes 
	@FindBy(id = "CActions")
	private  WebElement  corrActionOptions = driver.findElement( By.id("CActions"));
    private   List<WebElement> checkboxes = corrActionOptions.findElements(By.tagName("li"));
    private WebElement checkbox1 = driver.findElement(By.xpath("//*[@id='0']"));
    private   WebElement checkboxWOH = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '3']"));
    private   WebElement checkboxOthers = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '14']"));
    private    WebElement othersTxtBox = driver.findElement(By.id("txtCA"));
    private    WebElement submit_btn = driver.findElement(By.xpath("//*[@id='addNearMiss']/section/div/div[3]/button[2]"));

	 */
	//alert capture locators

	@FindBy(className ="checkboxmark")
	private List<WebElement> checkboxes;

	//severity list locator   
	@FindBy(xpath = "//*[@id='menuList']/li")
	private List<WebElement> severityList;

	//mandatory locators 
	@FindBy(className = "required")
	private WebElement value ;
	@FindBy(xpath ="//*[@id='addNearMiss']/section/div/div[1]/div[2]/div[1]/div[2]/div/span")
	private WebElement  incident_type_req;
	@FindBy(xpath="//*[@id='addNearMiss']/section/div/div[1]/div[4]/div[1]/span")
	private WebElement incident_at_req;
	@FindBy(xpath="//*[@id='addNearMiss']/section/div/div[1]/div[6]/div/div/span")
	private WebElement  severity_req;
	@FindBy(xpath="//*[@id='Summary-helper-text']")
	private WebElement summary_req;
	@FindBy(xpath="//*[@id='addNearMiss']/section/div/div[1]/div[10]/div[1]/span")
	private WebElement states_req;
	@FindBy(xpath="//*[@id='addNearMiss']/section/div/div[1]/div[10]/div[2]/span")
	private WebElement errors_req;
	@FindBy(xpath="//*[@id='addNearMiss']/section/div/div[1]/div[12]/div/div/span")
	private WebElement 	corrective_actions_req;

	// All other webelements 
	@FindBy(xpath = "//*[@id='Type_input']")
	//@FindBy(xpath="//*[@id='Type']/div[1]/i")
	private WebElement incType;
	@FindBy(xpath = "//*[@id='inc_title']/div/div") 
	private WebElement incTitle;
	@FindBy(xpath = "//*[@id='Date']")
	private WebElement incDate ;
	@FindBy(xpath = "//*[@id='Time']")  
	private WebElement incTime ;
	@FindBy(xpath = "//*[@id='Placeid1']")
	private WebElement incAt;
	@FindBy(xpath = "//*[@id='Location_input']")
	private WebElement location ;
	@FindBy(xpath = "//*[@id='Department_input']")
	private WebElement department;
	@FindBy(xpath = "//*[@id='menuList']")
	private WebElement severity;
	@FindBy(xpath = "//*[@id='addchoose']") 
	private WebElement chooseImg;
	@FindBy(xpath = "//*[@id='States']/div/label/span")
	private WebElement states ;
	
	@FindBy(xpath = "//*[@id='Errors']/div/label/span")
	private WebElement errors ;

	//methods


	//constructor
	public NearMissClass(WebDriver driver) 
	{ 
		//this.driver = driver ;
		PageFactory.initElements(driver, this);
	}

	//Actions
	public void clickSeverityList()
	{
		ArrayList<Integer> nums = new ArrayList<Integer>(Arrays.asList(0,1,2,3,5,6));	   
		Random random = new Random();
		int result = random.nextInt(nums.size());
		severityList.get(result).click();

	}
	public void checkStatesLabel() throws InterruptedException
	{
		int count4 = 0;
		System.out.println(" States and Errors labels");
		for ( WebElement e5 : statesAndErrorsLabel) {

			System.out.println(e5.getText());
			count4++;


		}
		System.out.println("number of states and errors label found:"+ count4);
		if (count4 == 8 )
		{
			System.out.println("States and Errors labels  of Near Miss page are visible .test pass.");
		}
		else
		{
			System.out.println("States and Errors labels  of Near Miss page are invisible .test failed.");
		}
	}
	public void verifyOpenButton()
	{

		if(openRadioBtn.isSelected())
		{
			System.out.println("open radio button is selected .test passed");
		}

		else 
		{
			System.out.println("open radio button is  not selected .test failed");
		}
	}
	public void verifyCloseButton()
	{

		if (closeRadioBtn.isSelected())
		{
			System.out.println("close radio button is selected .");
		}
		else 
		{
			System.out.println("Close  radio button is  not selected ");
		}
	}
	//Action methods
	//verify the images of the page and click them all 
	public void imagesClickAndCount()
	{
		int count3 = 0;
		for ( WebElement e3 : checkmarksNM ) {

			System.out.println("Image  displayed"+e3.isDisplayed());
			count3++;
			//e3.click();

		}
		System.out.println("number of images found:"+ count3);
	}
	//mandatory fields check

	public void mandatoryfieldsCheck()
	{

		submitBtn.click();
		Assert.assertEquals("required",value.getText(),"did not bring in required error msg .test failed");
		Assert.assertTrue(incident_type_req.isDisplayed(),"did not bring in required error msg .test failed");
		Assert.assertTrue(incident_at_req.isDisplayed(),"did not bring in required error msg .test failed");
		Assert.assertTrue( severity_req.isDisplayed(),"did not bring in required error msg .test failed");
		Assert.assertTrue(summary_req.isDisplayed(),"did not bring in required error msg .test failed");
		Assert.assertTrue(states_req.isDisplayed(),"did not bring in required error msg .test failed");
		Assert.assertTrue(errors_req.isDisplayed(),"did not bring in required error msg .test failed");
		Assert.assertTrue(corrective_actions_req.isDisplayed(),"did not bring in required error msg .test failed");
		System.out.println("test pass since it brought up all required error messages");
	}

	//HashMap<Integer,String> Labelmap=new HashMap<Integer,String>();
	//counting labels in AddNearMiss page
	public void labelCount()
	{
		int count = 0;
		for ( WebElement e1 : labelsNM ) {
			System.out.println("label :"+e1.getText());
			count++ ;

		}
		//Labelmap.isEmpty()
		System.out.println("number of labels found:"+ count);
	}
	// elements location method

	public void CheckQElementVisibilty()
	{
		int count = 0;
		for ( WebElement e2 : elementsNM ) {
			if(e2.isDisplayed()) {
				System.out.println("Element is :"+e2.getText());
				count++ ;}
			else
			{
				System.out.println("Questions are not visible in the Add NearMiss page.Test failed");
			}
		}

		System.out.println("number of elements found:"+ count);
	}



	// verify label presence


	public void verifyLabelsInNM()
	{

		for ( WebElement e : labelsNM ) {
			//      System.out.println("label :"+e.getText());
			if (e.isDisplayed())
			{
				System.out.println("Label is:"+e.getText());
			}
			else
			{
				System.out.println("Label is present within");
			}

		}

	}
	public void enterInSummary() throws InterruptedException
	{
		summary_input.click();
		summary_input.sendKeys("this is a test");

	}

	public void alertCaptureCheck() throws InterruptedException
	{
		WebElement checkboxWOH = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '3']"));
		WebElement checkboxOthers = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '14']"));
		WebElement othersTxtBox = driver.findElement(By.id("txtCA"));
		// Verifying CAoptions Special checkboxes and their new options and toast messages ");


		//	checkboxes.get(2).click();
		//	System.out.println("Using @FindBys, we found " + checkboxWOH.getSize()+ " element(s)");
		checkboxWOH.click();
		WebDriverWait wait=new WebDriverWait(driver, 8);
		WebElement alertmsg = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class = 'MuiAlert-message']")));
		if (alertmsg.isDisplayed())
		{
			System.out.println("Alert message is visible .test Pass");
		}
		else
		{
			System.out.println("Alert message is not visible .test Fail") ;
		}
		Thread.sleep(3000);
		checkboxOthers.click();

		othersTxtBox.click();
		othersTxtBox.sendKeys("Last textbox of the page");
		System.out.println("all checkboxes are verified.");

	}
	ArrayList<String> currentOptions = new ArrayList<String>();
	List<WebElement> listofIncidentTypes = driver.findElements(By.xpath("//*[@id='Type']/div[2]/ul/li"));
	
	/*
	 * Incident type dropdown list 
	 * 
	 */
	public ArrayList<String> finddropDownList()
	{

		IncTypeDownIcon.click();
		for ( WebElement e1 :listofIncidentTypes ) 
		{
		
			currentOptions.add(e1.getText());

		}
		return currentOptions;
	}
	public void  finddropDownListandclick()
	{

		IncTypeDownIcon.click();
		for ( WebElement e1 :listofIncidentTypes ) 
		{
		 if(e1.getText().equals("Safety"))
		 {
			 e1.click();
			 System.out.println("Quality option is chosen");
		 }
			currentOptions.add(e1.getText());

		}
		
	}
	/*
	 * 
	 * Incident at images option click
	 * 
	 */
	public void imagesIncidentAtClick()
	{

		ArrayList<Integer> numsLeft1 = new ArrayList<Integer>(Arrays.asList(0,1,2,3));	   
		Random random = new Random();
		int result = random.nextInt(numsLeft1.size());

		imagesIncAt.get(result).click();
		System.out.println("at random a number is chosen and that image is clicked ");

	}
	/*
	 * incident at count the images
	 * 
	 */
	public void imagesIncidentAtCount()
	{
		int  count4=0;
		//System.out.println("at random a number is chosen and that image is clicked ");
		for ( WebElement e4 : imagesIncAt)
		{

			System.out.println("Image "+count4+"is displayed ?"+e4.isDisplayed());
			count4++;


		}
		System.out.println("number of images found:"+ count4);
	}
	/*
	 * corrective actions labels check
	 * 
	 */

	public void CorrOptionsClick() throws InterruptedException
	{


		WebElement checkbox1 = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '1']"));
		WebElement checkbox8 = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '7']"));
		WebElement checkboxWOH = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '3']"));
		WebElement checkboxOthers = driver.findElement(By.xpath("//*[@class='checkboxmark' and @id= '14']"));
		WebElement othersTxtBox = driver.findElement(By.id("txtCA"));
		checkbox1.click();
		checkboxWOH.click();
		Thread.sleep(3000);
		checkbox8.click();
		checkboxOthers.click();
		othersTxtBox.sendKeys("testing testing");
		Thread.sleep(3000);
		System.out.println("Corr Action checkboxes are clickable and verified");

	}
	/*
	 * using sikuli entering file from local system and adding to the page
	 * 
	 */
	public void ChooseImageCheck() throws InterruptedException, FindFailed
	{
		//WebElement chooseImageBtn = driver.findElement(By.xpath("//*[@id='addchoose']"));
		//Actions a = new Actions(driver);
		//WebElement chooseImageBtn = driver.findElement(By.xpath("//*[@id='addchoose']"));
		chooseImage.click();


		Screen s1 = new Screen();

		//Pattern fileInputTextBox = new Pattern("C:\\Users\\vimci\\Desktop\\YF\\Example\\.\\sikuliximage-1626699599802.png");
		Pattern fileInputTextBox = new Pattern("C:\\Users\\vimci\\Desktop\\YF\\com.ssi\\src\\main\\java\\TestData\\InputTextboxSikuliImage.png");
		Pattern openButton = new Pattern("C:\\Users\\vimci\\Desktop\\YF\\com.ssi\\src\\main\\java\\TestData\\openButtonSikuliImage.png");	
		//Pattern openButton = new Pattern("C:\\Users\\vimci\\Desktop\\YF\\Example\\.\\sikuliximage-1626699870325.png");

		s1.highlight("yellow");

		s1.type(fileInputTextBox,"C:\\Users\\vimci\\Pictures\\take-regular-breaks.png");
		s1.wait(fileInputTextBox,2000);
		s1.click(openButton);
		Thread.sleep(3000);
		System.out.println("Choose Image button verified");
	}

	public void CAoptionsCheck() throws InterruptedException
	{
		System.out.println(" labels of checkboxesfound");
		int count5=0;
		for ( WebElement e5 : checkboxForCorrActions)
		{
			if(e5.isDisplayed())
			{

				count5++;
			}
			else
			{
				System.out.println("labels are not visible");
			}
		}
		System.out.println("Number of checkboxes found in Corrective actions is: "+count5);
	}


	/* list iterator
	@FindBy(id = "CActions")
	 private WebElement  corrActionOptions;
	  List<WebElement> checkboxes = corrActionOptions.findElements(By.tagName("li"));


   List <WebElement> lt =  corrActionOptions.findElements(By.tagName("li"));
	Iterator <WebElement> it= lt.iterator();
	while(it.hasNext())
	{
		if(it.next().getText()).equals())
		{
			it.next().click();
			break;
		}
	}*/
	public void validateNMEntry() throws InterruptedException	
	{
		/*ArrayList<String> incTypeList = finddropDownList();
		Select typeSelection = new Select(incType);
		typeSelection.selectByVisibleText("Finance"); 
		incTypeList.get(0)
		List<String> it = incTypeList;
		while((it).hasNext())
		{
			if(it.next().getText()).equals() "finance")
			{
				it.next().click();
				break;
			}
		}
		*/
 		Actions a = new Actions(driver);
		a.moveToElement(incTitle).click().sendKeys("Happy Test")
	//	.moveToElement(incType).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER)
	//	.moveToElement(incTypeList.get(1)).click()
		.moveToElement(incAt).click()
		.moveToElement(location).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER)
		.moveToElement(department).click().sendKeys(Keys.DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER)
		.moveToElement(summary_input).click().sendKeys("this is test summary ").sendKeys(Keys.ENTER)
	    .moveToElement(states).click()
	    .moveToElement(errors).click()     
		.moveToElement(checkboxes.get(1)).click()
		.moveToElement(submitBtn).sendKeys(Keys.ENTER)
		.build().perform(); 
		if (driver.findElement(By.xpath("//*[@id='addNearMiss']/div[3]/div/div[2]")).equals("Near Miss Incident updated successfully"))
		{
		System.out.println("alert message confirmed");
		}

		/*
		 * checking alert message when submit button is clicked 
		 * 
		 */
		//submitBtn.click();
		WebDriverWait wait=new WebDriverWait(driver, 8);
		WebElement alertmsg = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='addNearMiss']/div[3]/div/div[2]")));
		if (alertmsg.isDisplayed())
		{
			System.out.println("Alert message is visible .Entry is posted.test Pass");
		}
		else
		{
			System.out.println("Alert message is not visible.Check for missing mandatory fields.Test Fail") ;
		}
		
		
	}
    public void clickSubmit()
    {
    	submitBtn.sendKeys(Keys.ENTER);
    /*	WebDriverWait wait=new WebDriverWait(driver, 8);
		WebElement alertmsg = wait
			.until(ExpectedConditions.visibilityOfElementLocated(By.className("MuiAlert-message")));
    //	WebElement alertmsg = driver.findElement(By.xpath("//*[@class = "MuiAlert-message"]));
		System.out.println("alert message is:"+alertmsg);
		if (alertmsg.isDisplayed())
		{
			System.out.println("Alert message is visible .Entry is posted.Test Pass");
		}
		else
		{
			System.out.println("Alert message is not visible.Check for missing mandatory fields.") ;
		}*/
		
    }

	public boolean verifyNMListPresence()
	{
		return nearMissListLink.isDisplayed();

	}

	public NearMissListClass navigateToNearMissList() {
		nearMissListLink.click();
		return new NearMissListClass(driver);
	}



}


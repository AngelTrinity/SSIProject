package Tests;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ssi.Pages.LoginPageClass;
import com.ssi.Pages.ObjRepo;

import BaseClass.TestBaseClass;
import Utilities.TestUtilities;

public class ObjRepoTest {

	public   WebDriver driver;
	public static ObjRepo or;
	public Properties p;
	
	
	public String user = TestBaseClass.prop.getProperty("username");
	public String pwd = TestBaseClass.prop.getProperty("password");

	@BeforeClass
	public  void beforeClass() throws FileNotFoundException, IOException
	{
	    p = TestBaseClass.initialize();
		System.setProperty("webdriver.chrome.driver","C:/Users/vimci/Desktop/Drivers/chromedriver.exe");
		driver= new ChromeDriver();
			}
	@AfterClass
	public void afterClass()
	{
		driver.quit();

	}

	@Test
	public void setup() throws InterruptedException
	{  
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	driver.manage().timeouts().pageLoadTimeout(TestUtilities.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
	driver.get(p.getProperty("url"));
	or = new ObjRepo(driver);
	}
}

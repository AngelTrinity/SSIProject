package Tests;

import java.io.FileNotFoundException;
import java.io.IOException;

//import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ssi.Pages.HomePageClassEx;
//import com.ssi.Pages.LoginPageClassEx;

import BaseClass.BaseClassEx;

public class LoginPageClassTest extends BaseClassEx{
	HomePageClassEx homepage;
	@BeforeSuite
	public void setup() throws FileNotFoundException, IOException
	{
		BaseClassEx.startBrowser();;
		homepage=loginpage.toLogin("Happy", "test1234");
		
	}
	/*@Test
	public void validate1()
	{
	Assert.assertTrue(loginpage.verifyMenuIcon());
	}
	@Test
	public void validate2()
	{
	Assert.assertTrue(loginpage.verifyLogo());
	}
	@Test
	public void validate3()
	{
	homepage=loginpage.toLogin("Happy", "test1234");
	}*/
	@Test
	public void validate4()
	{
	System.out.println("verifying home icon"+homepage.verifyProfileIcon());
	System.out.println("verifying homepge header"+homepage.verifyHeader());
	System.out.println("current url is:"+ driver.getCurrentUrl());
	System.out.println("current title is :"+ driver.getTitle());
	}

}

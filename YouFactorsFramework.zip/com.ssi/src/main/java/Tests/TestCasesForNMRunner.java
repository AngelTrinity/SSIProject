/**
 * 
 */
package Tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
import BaseClass.*;
import com.ssi.Pages.*;
//import com.ssi.Pages.NearMissClass;

import Utilities.TestUtilities;

/**
 * trial run of NMtests using extent reports
 *
 */
public class TestCasesForNMRunner extends TestBaseClass
{public WebDriver driver;
	
	NearMissClass nearmissPage;	
	HomePageClass homePage;

	@FindBy(xpath = "//*[@id='showlistadd']")
	private WebElement  nearMissListLink;
	//constructor
public TestCasesForNMRunner()
{
	super();
}

	@Test 
	public void moveToNearMiss() throws InterruptedException 
	{  homePage =	loginPage.toLogin("Happy", "test1234");
	homePage.clickMenuIcon();
	nearmissPage =homePage.moveToNearMiss();
	NearMissClass nearmissPage = PageFactory.initElements(driver,NearMissClass.class);

	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);

	System.out.println("we are in :"+driver.getCurrentUrl());
	Assert.assertEquals(driver.getCurrentUrl(),"https://qasteercom.devssidevtech.com/schome/nearmiss");
	System.out.println("URL assertion passed"); 
	System.out.println("asserting radio btn");
	nearmissPage.verifyOpenButton();
	nearmissPage.enterInSummary();
	nearmissPage.labelCount();
	nearmissPage.verifyLabelsInNM();
	}
	@Test
	public void NMtest1()
	{
		nearmissPage.verifyCloseButton();
	}

}

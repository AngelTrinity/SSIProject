package Tests;


import java.io.FileNotFoundException;
import java.io.IOException;
//import java.util.concurrent.TimeUnit;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.model.Log;
import com.ssi.Pages.*;

import BaseClass.TestBaseClass;
import BaseClass.TestListenerClass;
import Utilities.TestUtilities;

import java.util.Properties;
import java.util.concurrent.TimeUnit;
public class TestRunner extends TestBaseClass
{
	public   WebDriver driver;
	public Properties p;
	//public ExtentTest test;
	public static LoginPageClass loginpage;
	public static HomePageClass homepage;
	public static NavigateToClass navigatepage;
	public static FindElementsinNM  nearmisspage;
	public String user =p.getProperty("username");
	public String pwd = p.getProperty("password");
	public String url = p.getProperty("url");
	//	public String userid = TestBaseClass.prop.getProperty("username");
	//public String pwd = TestBaseClass.prop.getProperty("password");
	//Constructor
	
	@BeforeClass
	public  void beforeClass() throws FileNotFoundException, IOException
	{
		// TestBaseClass.initialize();;
	
		System.setProperty("webdriver.chrome.driver","C:/Users/vimci/Desktop/Drivers/chromedriver.exe");
		driver= new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
		driver = new ChromeDriver();
		driver.get(url);
	}
	@AfterClass
	public void afterClass()
	{
		driver.quit();

	}

	@Test
	public void logintoYF() throws InterruptedException
	{   driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	driver.manage().timeouts().pageLoadTimeout(TestUtilities.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
	driver.get(url);
	loginpage = new LoginPageClass(driver);
	//test.log(Status.INFO,"Entering the Web Application");
	//String user =p.getProperty("username");
	//String pwd = p.getProperty("password");
	homepage = loginpage.toLogin(user,pwd);
	homepage = new HomePageClass(driver);
	//String title = driver.getTitle();
	//Assert.assertEquals(homepage.gtitle, "YouFactors");
	//TestListenerClass.logger("login done and title verified");
	Thread.sleep(3000);
	boolean logo = loginpage.validateLogo();
	Assert.assertTrue(logo);
	System.out.println("login done and title verified");
	Assert.assertTrue(loginpage.validateLogo());
	//homepage.goTosidePanel();
	System.out.println(" logo and profile Icon  verification");
	//Assert.assertTrue(loginpage.validateMenuIcon());
	Thread.sleep(3000);
	System.out.println("moving to menu");
	}

	@Test
	public void homepage()
	{
  //   or.toLogin(user,pwd); 
//	Assert.assertTrue(homepage.verifyLogoImage());
	Assert.assertTrue(homepage.verifyProfileIcon());
	}
}
/*	@Test 
	public void homePageVerify()
	{
		//homepage = new HomePageClass(driver);
	String h = homepage.verifyHeader();
	Assert.assertEquals(h,"Courses");
	System.out.println("header is :"+h);
	//homepage.
	//	homepage.goToNMPage();
	}


		TestListenerClass.logger("control moved to homepage");
		boolean verifyLogo = homepage.verifyLogoImage();
		Assert.assertTrue(verifyLogo);
		boolean verifyMenu = homepage.verifyMenuIcon();
		Assert.assertTrue(verifyMenu);
		boolean verifyProfile = homepage.verifyProfileIcon();
		Assert.assertTrue(verifyProfile);
		TestListenerClass.logger("verified presence of Menu icon,logo and profile Icon");
 */

/*@Test
	public void navigate()

	{
		LoginPageClass loginpage = new LoginPageClass(driver);
	String userid = TestBaseClass.prop.getProperty("username");
	String pwd = TestBaseClass.prop.getProperty("password");

	homepage=loginpage.toLogin(userid,pwd);
		loginpage = new LoginPageClass(driver);
		homepage = loginpage.toLogin(userid,pwd);

		nearmisspage=navigatepage.goToNMPage();

		String expectedURL = "https://qasteercom.devssidevtech.com";
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL,"URL assert failed");

		System.out.println("in login test");
		String title = loginpage.verifyTitle();
		Assert.assertEquals(title, "YouFactors");
		//test.log(Status.PASS,"title verified");
		System.out.println("Title verified");
	}
 */
/*	@Test

	public void navigation() throws InterruptedException
	{
		//String header = homepage.verifyHeader();
		//Assert.assertEquals(header,"Courses");
		boolean verifyLogo = homepage.verifyLogoImage();
		Assert.assertTrue(verifyLogo);
		boolean verifyMenu = homepage.verifyMenuIcon();
		Assert.assertTrue(verifyMenu);
		boolean verifyProfile = homepage.verifyProfileIcon();
		Assert.assertTrue(verifyProfile);
		System.out.println("verified presence of Menu icon,logo and profile Icon");
	}
	public void NMAccess()  throws InterruptedException
	{
	//some msg
	}
	/*	navigatepage = homepage.clickMenuIcon();
		Thread.sleep(3000);
		System.out.println("navigated to Menu");
		// nearmisspage=navigatepage.goToNMPage();
		Thread.sleep(3000);
		System.out.println("getting class for check"+nearmisspage.getClass());
		String header =nearmisspage.getHeader();
		//Assert.assertEquals(header, "Add Near Miss");
		System.out.println("nm page header is"+header);

	}
nearmisspage = new FindElementsinNM(driver);
	Thread.sleep(5000);
	System.out.println("Navigated to Near Miss Page");
	//String NMhead = nearmisspage.getHeader();
	//System.out.println("nm page header is"+NMhead);
	HashMap<Integer,String> Qmap = nearmisspage.findQsInNM();
	for (int i=0;i<6;i++)
	{
		System.out.println("question"+i+" is :"+Qmap.get(i));
	}
	System.out.println("All question labels are visible.");
}

@Test
public void NMPageImagesVerify() throws InterruptedException {

	//nearmisspage = new FindElementsinNM(driver);
	Thread.sleep(3000);
	String header =nearmisspage.getHeader();
	//Assert.assertEquals(header, "Add Near Miss");
	System.out.println("nm page header is"+header);
	//int imagecount = nearmisspage.findclickableImagesCount();
		//System.out.println("Clickable Images in Nm page:"+ imagecount);

	//boolean imageCheck = nearmisspage.VerifyImgVisibility();
	//Assert.assertTrue(imageCheck);
//	System.out.println("nonclickable image is displayed in Nm page");
}
 */

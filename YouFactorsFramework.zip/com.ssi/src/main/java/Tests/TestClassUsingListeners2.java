package Tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
//import org.apache.commons.compress.PasswordRequiredException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

//import com.aventstack.extentreports.Status;

//import BaseClass.TestBaseClass;
//import Utilities.TestUtilities;

import com.ssi.Pages.*;
import BaseClass.*;

import BaseClass.ExtentManager;
import Utilities.TestUtilities;

public class TestClassUsingListeners2
{
	public String methodName;
	public  static  WebDriver driver;
	public static Properties prop;
	public static  LoginPageClass loginPage;
	public static HomePageClass homePage;
	public  static NearMissClass nearmissPage,nmPage;
	public static  ExtentSparkReporter spark; 
	public static  ExtentReports  extent;
	public ExtentTest extentTest;

	@BeforeClass
	public  static void initialize() throws IOException ,FileNotFoundException
	{  
		//initialising extent report

		spark = new ExtentSparkReporter("NearMissReportOctober.html");
		spark.config().setDocumentTitle("SafeStart International ");
		spark.config().setReportName("Near Miss Module reports");
		
	//	extent.setSystemInfo("Organisation","SSI");
//		extent.setSystemInfo("Browser","Chrome");
		extent.attachReporter(spark);


		String filepath = System.getProperty("user.dir");
		prop = new Properties();
		FileInputStream ip = new FileInputStream(filepath+"/src/main/java/Utilities/configuration.Properties");
		prop.load(ip);

		//initialize browser

		String browserName = prop.getProperty("browser");

		if (browserName.equals("chrome"))
		{ // WebDriverManager.chromedriver().setup();
			System.setProperty("webdriver.chrome.driver","C:/Users/vimci/Desktop/Drivers/chromedriver.exe");
			driver= new ChromeDriver();

			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(TestUtilities.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
			driver.get(prop.getProperty("url"));

		}


		loginPage= new LoginPageClass(driver);

		/*  extent = new ExtentReports();
	     ExtentSparkReporter spark = new ExtentSparkReporter("NearMiss_Report.html");
	     extent.attachReporter(spark);

		//ExtentTest test1 = extent.createTest("Google Search Test");*/


	}	
	@AfterClass
	public void tearDown() {
		extent.flush();
		driver.close();
	}
	@AfterMethod
	public void aftermethod(ITestResult result)
	{
		String methodName = result.getMethod().getMethodName();

		/*	String logText1 = "<b> Test Method "+methodName+ " started</b>";	
			Markup m1 = MarkupHelper.createLabel(logText1,ExtentColor.BLUE);
			extentTest.get().log(Status.INFO, m1);*/

		if (result.getStatus() == ITestResult.FAILURE)
		{
			String exceptionMsg = Arrays.toString(result.getThrowable().getStackTrace());
			extentTest.fail("<Details><Summary><b><Font color= red>" 
					+ "Exception Occured.Click here to see details"
					+"</font></b></Summary>"+exceptionMsg.replaceAll(",","<br>")
					+"</Details>\n");
			//WebDriver driver=((Tests.TestRunner)result.getInstance()).driver;
			String path = takeScreenshot(result.getMethod().getMethodName());
			try
			{
				extentTest.fail("<b><font color = red>"+"Screenshot of Failure"+"</font></b>" );
				MediaEntityBuilder.createScreenCaptureFromPath(path).build();
				
				//	if (path == null || path.isEmpty())
				//    throw new IOException("ScreenCapture path cannot be null or empty.");
				//	extentTest.addScreenCaptureFromPath(path);
			}
			catch(Exception e)
			{
				extentTest.fail("Test failed ,cannot take a screenshot");
			}
			String logText = "<b> Test Method "+methodName+ " Failed </b>";	
			Markup m = MarkupHelper.createLabel(logText,ExtentColor.RED);
			extentTest.log(Status.FAIL, m);
		}
		else if (result.getStatus() == ITestResult.SUCCESS)
		{
			String logText = "<b> Test Method "+methodName+ " passed </b>";	
			Markup m = MarkupHelper.createLabel(logText,ExtentColor.GREEN);
			extentTest.log(Status.PASS, m);	
		}

		else if (result.getStatus() == ITestResult.SKIP)
		{
			String logText = "<b> Test Method "+methodName+ "skipped </b>";	
			Markup m = MarkupHelper.createLabel(logText,ExtentColor.YELLOW);
			extentTest.log(Status.SKIP, m);	
		}
	}
	public static String  takeScreenshot(String methodName)
	{
		String fileName = getScreenshotName(methodName);
		String directory = System.getProperty("user.dir")+"/Screenshots/";
		new File(directory).mkdirs();
		String path = directory+fileName;
		try
		{
			File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(path));
			System.out.println("------------------------------");
			System.out.println("Screenshot saved in :"+path);
			System.out.println("------------------------------");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return path;
	}
	public static  String getScreenshotName(String methodName)
	{
		Date d1 = new Date();
		String fileName = "Automated Report_"+d1.toString().replace(",","_").replace(":","_").replace(" ","_")+".png";

		return fileName;
	}
	
/*	@Test(priority = 1)
	public void mandatoryCheck() throws InterruptedException
	{
  	extentTest = extent.createTest("Mandatory fields check");
  	homePage =	loginPage.toLogin("Happy", "test1234");
	homePage.clickMenuIcon();
     nmPage =homePage.moveToNearMiss();
	NearMissClass nmPage = PageFactory.initElements(driver,NearMissClass.class);
    nearmissPage = nmPage;
	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	 nearmissPage.labelCount();
	}*/
  /*lauching nearmisspage
	
	public NearMissClass initiation() throws InterruptedException
	{
		 homePage =	loginPage.toLogin("Happy", "test1234");
			homePage.clickMenuIcon();
	         nmPage =homePage.moveToNearMiss();
			NearMissClass nmPage = PageFactory.initElements(driver,NearMissClass.class);

			driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
	return nmPage;
	}
*/
	// introducing Login page tests

	@Test(priority = 1)
	public void MoveToTest() throws InterruptedException {
		//extentTest = extent.createTest("Login  Test");
		extentTest.log(Status.INFO,"We are in : "+driver.getCurrentUrl());
		homePage =	loginPage.toLogin("Happy", "test1234");

		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		System.out.println("We have moved to: "+driver.getCurrentUrl());

	}
	@Test(priority = 0)
	public void logoTest()
	{
	//	extentTest = extent.createTest("Logo Test");
		loginPage = new LoginPageClass(driver);
		Assert.assertTrue(loginPage.validateLogo(),"Logo not visible");
         System.out.println("logo verified");
	}
	@Test(priority = 2)
	
	public void TitleTest()
	{
		extentTest = extent.createTest("Title Test");
		System.out.println("title from Landingpage:"+driver.getTitle());
		Assert.assertEquals(driver.getTitle(), "YouFactors");
	System.out.println("Title verified");
	}

	/*	 @Test(priority = 9)
		public void moveToNearMiss() throws InterruptedException 

		{ 
			// ExtentReports extent;
			extentTest = extent.createTest("Navigate to Near Miss Test");

		 LoginPageClass loginPage = PageFactory.initElements(driver,LoginPageClass.class);
		// loginPage.validateLogo();
				loginPage= new LoginPageClass(driver);
		 homePage =	loginPage.toLogin("Happy", "test1234");
	 //   driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		 homePage = PageFactory.initElements(driver,HomePageClass.class);
		//homePage.clickMenuIcon();
		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);

		homePage.clickMenuIcon();
		nearmissPage = homePage.moveToNearMiss();

	   // nearmissPage = PageFactory.initElements(driver,NearMissClass.class);

		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);


	//	driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);

		System.out.println("we are in :"+driver.getCurrentUrl());
		extentTest.log(Status.INFO,"we are in "+driver.getCurrentUrl());

		Assert.assertEquals(driver.getCurrentUrl(),"https://qasteercom.devssidevtech.com/schome/nearmiss");
		System.out.println("URL assertion passed"); 
		System.out.println("asserting radio btn");
		nearmissPage.verifyOpenButton();
		nearmissPage.enterInSummary();
		nearmissPage.labelCount();
		nearmissPage.verifyLabelsInNM();
		nearmissPage.verifyCloseButton();
		nearmissPage.CheckQElementVisibilty();
		}
		//nearmissPage.imagesClickAndCount();  
	 @Test(priority = 4)
	public void MoveToHomePage() throws InterruptedException {
		extentTest = extent.createTest("HomePage header Test");
		System.out.println("We are in : "+driver.getCurrentUrl());
		homePage =	loginPage.toLogin("Happy", "test1234");
		HomePageClass homePage = PageFactory.initElements(driver,HomePageClass.class);
		System.out.println("We have moved to : "+driver.getCurrentUrl());
		Thread.sleep(3000);
		//Assert.assertTrue(homePage.verifyHeader());
		Thread.sleep(2000);
		System.out.println("We have moved to after few secs: "+driver.getCurrentUrl());
		System.out.println("verified header in Homepage");
	}*/
/*	@Test(priority = 5)
	public void verifyMenuIcon()
	{ 
		extentTest = extent.createTest("MenuIcon Presence Test");
		
		homePage =	loginPage.toLogin("Happy", "test1234");
		HomePageClass homePage = PageFactory.initElements(driver,HomePageClass.class);
	//	Assert.assertTrue(homePage.verifyMenuIcon());
	//	extentTest.log(Status.INFO,"MenuIcon is present");
	}
	
	@Test(priority = 6)
	public void verifyProfileIcon()
	{
		extentTest = extent.createTest("Verify Profile Icon Presence Test");
		homePage =	loginPage.toLogin("Happy", "test1234");
		Assert.assertTrue(homePage.verifyProfileIcon());
	//	extentTest.log(Status.INFO,"ProfileIcon is present");
	}
	
	@Test(priority = 7)
	public void clickMenuIcon()
	{   extentTest = extent.createTest("MenuIcon Test");
		homePage =	loginPage.toLogin("Happy", "test1234");
		homePage.clickMenuIcon();
		//extentTest.log(Status.INFO,"MenuIcon is clicked");
	}
	@Test(priority = 8)
	public void checkHeader()
	{
		extentTest = extent.createTest("HomePage header verification Test");
	homePage =	loginPage.toLogin("Happy", "test1234");
 //   extentTest.log(Status.INFO,"header is :"+homePage.verifyHeader());
	 }
	 */
/*	@Test(priority = 3)
	public void test2fail()
	{
		extentTest = extent.createTest("created Test to fail");
		Assert.fail();
		//extentTest.log(Status.FAIL,"test failed");
	}
	@Test(priority = 2)
	public void test2Skip()
	{
		extentTest = extent.createTest("created Test to Skip - demo");
		//extentTest.log(Status.INFO,"test skipped");
		throw new SkipException("Skipped the test due to config errors");
	}
	@Test(priority = 1)
	public void mandatoryCheck() throws InterruptedException
	{
  	extentTest = extent.createTest("Mandatory fields check");
	/*	homePage =	loginPage.toLogin("Happy", "test1234");
		homePage.clickMenuIcon();
		nearmissPage =initiation();

		NearMissClass nearmissPage = PageFactory.initElements(driver,NearMissClass.class);

		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		nearmissPage =initiation();
		nearmissPage.labelCount();; 
	}
*/

}

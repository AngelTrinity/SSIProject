package Tests;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

import com.ssi.Pages.FindElementsinNM;
import com.ssi.Pages.HomePageClass;
import com.ssi.Pages.LoginPageClass;
import com.ssi.Pages.NavigateToClass;

import BaseClass.TestBaseClass;
import Utilities.TestUtilities;

public class PageChainingTillNM extends TestBaseClass
{
	public   WebDriver driver;
	public static LoginPageClass loginpage;
	public static HomePageClass homepage,homepage1;
	public static NavigateToClass navigatepage,nav;
	public static FindElementsinNM nearmisspage;
	@FindBy (xpath="//*[@id='addNearMiss']/div[1]/div/h3")
	private WebElement NMheader1;
	@FindBy(xpath = "//*[@id='main-content']/div[1]/div/div/div/div/div[1]/h3")
	private WebElement LandingpageHeader1;
	//
	public PageChainingTillNM()
	{
		super();
	}
	@BeforeClass
	public  void setup() throws FileNotFoundException, IOException
	{
		//WebDriver driver =
	// loginpage= TestBaseClass.initialize();
	}
	@Test
	public void verifyLogin() throws FileNotFoundException, IOException
	{//loginpage.clickMenuIcon();
	driver = loginpage.driver;
	    loginpage= TestBaseClass.initialize();
	
		System.out.println("system is runningthis page:"+driver.getCurrentUrl());
		System.out.println("web page title is :"+driver.getTitle());
	
	//Assert.assertTrue(loginpage.validateLogo());
	System.out.println("logo validated");
		//Assert.assertTrue(loginpage.validateMenuIcon());
	}
/*
 * '
 * 
 * 
 * 	public void loginToYF()  throws InterruptedException
	{
		String uname = TestBaseClass.prop.getProperty("username");
		String passwd = TestBaseClass.prop.getProperty("password");
		loginpage = new LoginPageClass(driver);

		homepage =loginpage.toLogin(uname, passwd);
		System.out.println("we are in :"+driver.getCurrentUrl());
		 homepage.clickMenuIcon();
			WebDriverWait w= (new WebDriverWait(driver, 8));
			w.until(ExpectedConditions
					.visibilityOf(LandingpageHeader1));
			System.out.println("we are in :"+driver.getCurrentUrl());
			Thread.sleep(3000);
	}
	@Test
	public void moveToHomepage() throws InterruptedException
	{       homepage.clickMenuIcon();
	WebDriverWait w= (new WebDriverWait(driver, 8));
	w.until(ExpectedConditions
			.visibilityOf(LandingpageHeader1));

	//driver.manage().timeouts().pageLoadTimeout(TestUtilities.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
	//  System.out.println("logo verify :"+homepage.verifyLogoImage());
	System.out.println("we are in :"+driver.getCurrentUrl());
	Thread.sleep(3000);

	//  navigatepage = homepage.goToNMPage();
	//to resolve element not interactable 
	}
	@Test
	public void moveToNavigateToClass()
	{
		/*WebDriverWait w1= (new WebDriverWait(driver, 10));
		w1.stem.out.println("we are in :"+driver.getCurrentUrl());
		Thread.sleep(3000);
		
	}

*/

	@AfterSuite
	public void tearDown()
	{
		driver.quit();
		//System.out.println(nearmisspage.getHeader());	
	}

}

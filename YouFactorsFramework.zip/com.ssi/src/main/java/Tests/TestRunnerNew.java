package Tests;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ssi.Pages.FindElementsinNM;
import com.ssi.Pages.HomePageClass;
import com.ssi.Pages.LoginPageClass;
import com.ssi.Pages.NavigateToClass;
import com.ssi.Pages.NearMissClass;

import BaseClass.TestBaseClass;
import Utilities.TestUtilities;

public class TestRunnerNew extends TestBaseClass
 {
	
	public   WebDriver driver;
	public Properties p;
	public static LoginPageClass loginPage;
	public static HomePageClass homePage;
	public static NavigateToClass navigatepage;

	public static NearMissClass nearmissPage, nmPage;

	
	@BeforeClass
	public  void beforeClass() throws FileNotFoundException, IOException
	{
		// TestBaseClass.initialize();
	
		System.setProperty("webdriver.chrome.driver","C:/Users/vimci/Desktop/Drivers/chromedriver.exe");
		driver= new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
		driver = new ChromeDriver();
		driver.get(p.getProperty("url"));
		loginPage = new LoginPageClass(driver);
	}
	@AfterClass
	public void afterClass()
	{
		driver.quit();

	}
	
	@Test
	public void questionLabelCheck() throws InterruptedException
	{
		homePage =	loginPage.toLogin(p.getProperty("username"), p.getProperty("password"));
		HomePageClass homePage = PageFactory.initElements(driver,HomePageClass.class);

		homePage.clickMenuIcon();
		nearmissPage =homePage.moveToNearMiss();
		NearMissClass nearmissPage = PageFactory.initElements(driver,NearMissClass.class);

		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		nearmissPage.CheckQElementVisibilty();
	}
	
	
	/*public NearMissClass initiation() throws InterruptedException
	{
	//	homePage =	loginPage.toLogin("Happy", "test1234");
		homePage.clickMenuIcon();
		nmPage =homePage.moveToNearMiss();
		NearMissClass nmPage = PageFactory.initElements(driver,NearMissClass.class);

		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		return nmPage;
	}
	*/
 }
	

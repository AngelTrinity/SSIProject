package BaseClass;

import java.io.File;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager
{
	public static ExtentReports extent;
	public static  ExtentSparkReporter spark;
	
	public static ExtentReports createInstance()
	{
		String filename1 = getReportName();
		String directory = System.getProperty("user.dir")+"/reports/";
		new File(directory).mkdirs();
		String path = directory+filename1;
		  
	     ExtentSparkReporter spark = new ExtentSparkReporter(path);
	    // spark = new ExtentSparkReporter("./reports/extent.html");
		  extent = new ExtentReports();
		  extent.setSystemInfo("Organisation","Safestart International");
		  extent.setSystemInfo("Browser","Chrome");
	      extent.attachReporter(spark);
		
		spark.config().setDocumentTitle("YouFactors");
		spark.config().setReportName("Near Miss Module Report");
      spark.config().setTheme(Theme.STANDARD);
      return extent;
	}
	public static String getReportName()
	{
		//SimpleDateFormat format = new SimpleDateFormat();
		Date date= new Date();
		String filename="Automated Report_"+date.toString().replace(":","_").replace(" ","_")+".html";
		
		return filename;
		
	}

	
}

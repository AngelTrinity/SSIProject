package BaseClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.ssi.Pages.LoginPageClass;
//import com.ssi.Pages.LoginPageClassEx;

import Utilities.TestUtilities;

public class BaseClassEx  {
	public static   WebDriver driver;
	public static 	Properties prop;
	public static LoginPageClass loginpage;
	public  static void  startBrowser()  throws IOException,FileNotFoundException
	{  //WebDriver driver;
	    
		String filepath = System.getProperty("user.dir");
			prop = new Properties();
			FileInputStream ip = new FileInputStream(filepath+"/src/main/java/Utilities/configuration.Properties");
			prop.load(ip);
				
	
		
		//initialize browser
		
		String browserName = prop.getProperty("browser");

		if (browserName.equals("chrome"))
		{ // WebDriverManager.chromedriver().setup();
		    System.setProperty("webdriver.chrome.driver","C:/Users/vimci/Desktop/Drivers/chromedriver.exe");
			driver= new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(TestUtilities.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		}
	
  loginpage = new LoginPageClass(driver);

		
	}
	@AfterSuite
	public void teardown()
	{
		driver.close();
	}
	

}

package BaseClass;

import org.testng.annotations.AfterMethod;
import java.io.File;
import java.io.FileInputStream;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ssi.Pages.LoginPageClass;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Utilities.TestUtilities;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBaseClass {
	
	public static  WebDriver driver;
	public static Properties prop;
	public static ExtentReports extent;
//	public static  ExtentSparkReporter spark;
	public static LoginPageClass loginPage;
	
	@BeforeMethod

	public  static void initialize() throws IOException  
	//throws IOException,FileNotFoundException
	{ 
		
		String filepath = System.getProperty("user.dir");
			prop = new Properties();
			FileInputStream ip = new FileInputStream(filepath+"/src/main/java/Utilities/configuration.Properties");
			prop.load(ip);
				
		//initialize browser
		
		String browserName = prop.getProperty("browser");

		if (browserName.equals("chrome"))
		{ // WebDriverManager.chromedriver().setup();
			//C:\Users\vimci\Desktop\Drivers\chromedriver_win32 (3)
		    System.setProperty("webdriver.chrome.driver","C:/Users/vimci/Desktop/Drivers/chromedriver_win32 (3)/chromedriver.exe");
			System.setProperty("webdriver.chrome.silentOutput","true");		
			driver= new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(TestUtilities.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		
               }
		
		try {
			loginPage= new LoginPageClass(driver);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		 String username = prop.getProperty("username");
			String password = prop.getProperty("password");
	
	
	}	

	@AfterMethod
	 public void tearDown() {
	  driver.close();
	 }
	/*	public  void  failedMethodtakeScreenshot(WebDriver driver,String method)
		String filename = getScreenshotName(methodName);
		String directory = System.getProperty("user.dir")+"/Screenshots/";
		new File(directory).mkdirs();
		String path = directory+filename;
		try
		{
			File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(path));
			System.out.println("------------------------------");
			System.out.println("Screenshot saved in :"+path);
			System.out.println("------------------------------");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//return path;
	}*/
	 
}



package Utilities;


	import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
	import org.testng.ITestListener;
	import org.testng.ITestResult;

import com.ssi.Pages.HomePageClass;
import com.ssi.Pages.SettingsClass;

import Utilities.TestUtilities;
	
	
	
	
	public class CustomListenerTestNG extends TestBaseClass implements ITestListener {
		public String filePath ="C:/Users/vimci/Desktop/YF/com.ssi/Screenshots";
		
		public void onStart(ITestContext context) {	
			String username = prop.getProperty("username");
			String password = prop.getProperty("password");
			HomePageClass homePage =	loginPage.toLogin(username,password);
			//Thread.sleep(3000);
			driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
			System.out.println("we are in :"+driver.getCurrentUrl());
			SettingsClass settingsPage=homePage.clickSettings();
			driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
			System.out.println("we are in :"+driver.getCurrentUrl());
		//	SettingsClass settingsPage = PageFactory.initElements(driver,SettingsClass.class);

			driver.manage().timeouts().implicitlyWait(TestUtilities.IMPLICIT_WAIT,TimeUnit.SECONDS);
			//System.out.println("onStart method started");
		}

		public void onFinish(ITestContext context) {
			//System.out.println("onFinish method started");
		}
		
			public void onTestStart(ITestResult result) {
				System.out.println("New Test Started" +result.getName());
			}
			
			public void onTestSuccess(ITestResult result) {
				System.out.println("onTestSuccess Method" +result.getName());
			}

			public void onTestFailure(ITestResult result) {
				System.out.println("onTestFailure Method" +result.getName());
				String methodName=result.getName().toString().trim();
		        ITestContext context = result.getTestContext();
		       WebDriver driver = (WebDriver)context.getAttribute("driver");
		    	takeScreenShot(methodName,driver);
				
			}

			public void onTestSkipped(ITestResult result) {
				System.out.println("onTestSkipped Method" +result.getName());
			}

			public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
				System.out.println("onTestFailedButWithinSuccessPercentage" +result.getName());
			}
			  public void takeScreenShot(String methodName, WebDriver driver) {
				  String filePath = System.getProperty("user.dir");
			    	 File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			         
			            try {
							FileUtils.copyFile(scrFile, new File(filePath+methodName+".png"));
							System.out.println("***Placed screen shot in "+filePath+" ***");
						} catch (IOException e) {
							e.printStackTrace();
						}
			    }

}

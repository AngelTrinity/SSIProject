package Utilities;

public class TestUtilities {
	
public	static long IMPLICIT_WAIT=10;
public 	static long PAGE_LOAD_TIMEOUT=20;
	 

}
